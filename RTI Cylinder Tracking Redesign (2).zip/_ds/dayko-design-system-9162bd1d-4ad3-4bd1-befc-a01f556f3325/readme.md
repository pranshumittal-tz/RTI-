# Dayko Design System

Dayko is a workspace product: a left icon rail of workspaces, a collapsible side menu of spaces and apps, and a document/record surface. The Figma source (`DesignSystem DaylightOS1.fig`) is a component library rather than a product file — it defines the primitives, the token collections and the shell chrome, plus a small set of first-party apps that plug into the rail (AI notetaker, Beacon, E-Sign, SuperCRM, Kindle, Echo).

**Source of truth:** the attached Figma file `DesignSystem DaylightOS1.fig` (pages: Foundation, Branding, Logo, and one page per component family, plus Shell / Sidebar / Header / Grids / Side-drawer). No codebase or repository was provided. No live Figma URL was supplied, so this project is the durable record.

Everything here — tokens, components, icons, the logo — was extracted from that file. Nothing was designed from memory.

---

## Content fundamentals

Copy in the kit is short, lower-pressure and mostly noun-first. Observed patterns:

- **Sentence case everywhere** for interface labels — `New deal`, `Select an item`, `Type your message here.`, `Ask Ray....`. Title Case appears only in proper nouns (`Personal Space`, `Mairaj HQ`, `AI notetaker`).
- **ALL-CAPS, letter-spaced, 10–11px** for section dividers in the side menu: `PERSONAL SPACE`, `TEAM SPACE`, `APPS`. This is the only place caps are used.
- **Second person is implied, not written.** Labels are objects and actions (`Deals`, `Save changes`), not sentences addressed to the user. There is no "your" in the chrome.
- **Placeholders describe the field, not the action** — `Select an item`, `Search..`, `Type your message here.`
- **No emoji in product UI.** Emoji appear only in the Figma documentation frames themselves (`✍️ Heading H1` on the typography specimen), never inside a component.
- **Keyboard shortcuts are shown as glyphs** — `⌘K` sits inside the search field as a muted chip.
- **Punctuation is loose.** `Search..` (two dots), `Ask Ray....` (four) — the source is not fussy about ellipses; match its casual register rather than "correcting" it.
- Status language is one or two words, no verbs: `Qualified`, `Proposal`, `On hold`, `Closed lost`, `Admin`.

The vibe is a calm internal tool. Nothing exclaims. Nothing sells.

## Visual foundations

**Colour.** The system is near-monochrome with one warm accent. The primary is a near-black `#18191D`; the brand accent is a soft coral `#F87171`, used sparingly (logo mark, focus emphasis, small marks) rather than as a fill for large surfaces. Neutrals are *warm* — the ramp runs `#FAFAF8 → #121110`, not a cool grey. Four saturated hues carry semantics: pink `#F12166` (highlight/active), teal `#00C287` (success, positive trend), blue `#533EED` (informational), yellow `#FFC524` (warning/pending). Each has a full 50–800 ramp. Full ramps: `guidelines/colors-*.card.html`.

**Type.** Geist is the interface face and carries almost everything — Regular for body, Medium for emphasis and labels, SemiBold for headings. The scale is tight: H1 24, H2 20, H3 16, H4 14; body 16/14/12 with 20px line height at 14. Archivo (24 Medium / 16 Regular) and Funnel Sans appear on branding and marketing frames. Inter shows up at 11px in dense annotation layers. Roboto Mono 14 Medium is the code/numeric face. The Dayko wordmark is set in **Satoshi Bold**.

**Spacing.** A 4px base: 0, 4, 8, 12, 16, 20, 24, 32, 48, 64. Buttons pad `8px 16px` with an 8px gap; the side menu pads `8px 12px`; header bars pad `8px 20px`. Rows in a list stack with a 2px gap, not 8 — the chrome is dense.

**Radius.** none 0, sm 4, md 8, lg 16, xl 20, full 9999. Buttons, inputs, cards and panels all sit at **8**. Chips and avatars use full. Nothing in the kit uses 6 or 12 as a default.

**Borders.** One hairline, one weight: `1px solid` at `#EDECEA` (default) or `#D8D6D2` (strong). Shell dividers use `#D9D9D9`. There are no 2px borders and no coloured left-accent rules.

**Elevation.** Seven steps, all black at 5–10% opacity, never tinted: 2xs `0 1px 0 rgba(0,0,0,.05)` → 2xl `0 25px 50px -12px rgba(0,0,0,.1)`. Cards use xs or sm. Popovers and dropdowns use md/lg. Nothing floats higher than 2xl.

**Cards and surfaces.** White card on a warm off-white page (`#FAFAF8`), 1px `#EDECEA` border, radius 8, shadow xs. Border *and* shadow together — the kit does not choose one or the other. Panels inside a screen drop the shadow and keep the border.

**Backgrounds.** Flat. No gradients, no photographic hero imagery, no illustration, no texture or noise anywhere in the file. The only non-flat fills are three small PNG avatar photographs. Depth comes from the neutral ramp, not from imagery.

**Transparency and blur.** Used only for shadow colours (`rgba(0,0,0,.05–.1)`) and one 60% black scrim. No frosted-glass panels, no backdrop blur.

**States.** Hover darkens or tints toward the neutral ramp (`bg-light`/`bg-subtle`) rather than changing opacity. Focus draws a border in `--color-border-focus` (near-black), not an outer glow ring. Disabled swaps text to `--color-text-tertiary` and background to a 100-level tint; it does not reduce opacity. Press states are not separately defined in the kit — hover and active share one variant (`hover & active` on Button and IconButton). Error uses the accent-400 red `#F30C0C` for border and text.

**Motion.** The Figma file defines no transitions, easing curves or prototype animation. Treat motion as undefined: if you need it, use short (120–160ms) linear-to-ease-out fades and colour transitions, and note the addition.

**Layout.** The app shell is fixed: 52px icon rail, 220px side menu, fluid content, 1440×832 design viewport. The header bar is 1px-ruled and sticky at the top of the content column. There is a Grids page defining desktop and mobile grids.

## Iconography

One coherent line set, ~177 glyphs, all drawn on a 24px box at a light stroke and exported with `currentColor`. There is **no icon font and no sprite sheet** — every glyph is vector geometry in the Figma file. They are materialised here as `assets/icons/icon-data.js` (name → `{viewBox, body}`) with an `<Icon name="…" size={…} />` wrapper. Recolour by setting `color` on the element.

Glyph coverage is business-workspace: files and documents, people and permissions, money and deals, calendar and time, media controls, text-editor formatting, plus brand marks (Google, Microsoft, LinkedIn, Twitter). Sizes in use are 16 and 20; 12 for inline decorations.

A second group of icons are *stateful component sets* rather than static glyphs — `Chevron`/`Arrow` (4 directions), `Trend` (5 directions), `Star`/`Home`/`CheckCircle`/`CloseCircle`/`CircleAlert` (filled/outline), `SquareCheck` (3 states), `Thumbs`, `Panel`/`PanelLeft`, `UploadDownload`, `Numbers`. These live in `components/icons/` with their variant props intact.

No emoji and no Unicode pictographs are used as icons. The one Unicode character that does appear in UI is `⌘` in the search shortcut chip.

## Brand assets

The Figma file contains a real Dayko mark: a semicircle with three stepped bars, in coral `#F87171`, paired with the word "Dayko" in Satoshi Bold. Copied to `assets/logo.svg` (mark), `assets/logo-light.svg`, `assets/logo-mark.svg`, `assets/logo-mark-dark.svg`. A second, unrelated lockup lives inside the `Logo` component (a 9-letter wordmark used by the shell frames); it is preserved as-is in `components/core/Logo.jsx`.

There are no brand illustrations, no photography beyond three small avatar PNGs, and no marketing imagery in the source.

---

## Index

- `styles.css` — the entry point consumers link. `@import`s only.
- `tokens/fig-tokens.css` — 586 Figma Variables across 12 collections, light and dark modes.
- `tokens/fonts.css` — Google Fonts imports and family aliases.
- `tokens/base.css` — link colours.
- `tokens/fig-typography.css` — generated; the source file defines no named text styles (see caveats).
- `assets/` — logo SVGs; `assets/icons/` — the 160-glyph icon data + `Icon` wrapper.
- `guidelines/*.card.html` — foundation specimen cards (colour, type, spacing, radius, elevation, brand).
- `components/` — the component library, grouped by concern.
- `ui_kits/dayko_app/` — an interactive recreation of the Dayko workspace shell.
- `SKILL.md` — Agent Skills entry point.

### Components

**core** — Avatar, Badge, Button, Hyperlink, IconButton, IconSquareDashed, IconSquareDashed2, Label, Logo, Plus4, Separator, SquareDashed

**forms** — Checkbox, Checkbox3, CheckboxGroup, Checkmark, IconMinus2, Input, Marker, Radio, RichCheckboxGroup, SelectCombobox, SliderHorizontal, Switch, SwitchGroup, SwitchTrueDefault, Textarea

**feedback** — AIChips, Alert, CircleAlert, CircleCheck, LoaderCircle2, Sonner, SonnerContent, Sparkles, StatusChips, TagsChips, Toaster, Tooltip

**data** — Arrow, Calendar, Calendar2, CalendarDay, CalendarHeader, CalendarWeekdayName, Chevron, DatePicker, Dropdown, Ellipsis, IconButton2, TabStyle, TabStyle1, TableCell, TableHeader

**navigation** — AppLogos, AppsIcon, AppsMenu, Bolt, Building, CalendarFold, Check, Command, Deal, Echo, EchoAppMenu, EchoLogo, FolderList, HeaderSearch, Home, InfoMenu, Initial, KindleAppMenu, LifeBuoy, Logo2, Menu, MenuIcon, MenuItems, MenuSearch, MessageCircle, Mic, NavMenu, PageTitle, Profile, Puri, Recording, Search, Search2, SendHorizontal, Setting2_, ShieldUser, SideMenu, Sidebar, SidebarIcon, Slot, SlotInner, SpaceMenu, SquaresExclude, Store, SubMenuItem, SubMenuItems, SideDrawer, PageHeader, AppMenuCollapsed, Close2, TextEditor, Users, WorkSpace, X, Zap

**icons** (stateful sets) — CheckCircle, CloseCircle, Component1, Numbers, Panel, PanelLeft, SquareCheck, Star, Thumbs, Trend, UploadDownload

**internal** (slot parts and Figma library scaffolding used inside other components) — AIAssistant, Avatar2, Checkbox2, ComponentPageHeader, Container, Frame1984078199, IconCheck, IconCircleDashed, IconMinus, InputDecoration, PrimarySmall, ProWarning, SelectComboboxRightDecoration, SelectLeftDecoration

**glyphs** (one component per single-purpose line icon) — Apps, Archive, ArrowUpDown, Attachment, Bank, Brain, BusinessCase, CalendarClock, Captions, Car, ChartArea, CircleDotDashed, CirclePile, Clock9, Close, Columns3Cog, CommandK, Connect, Construction, Contract, Copy, CornerDownRight, DollarCircle, Dot, Download, Dumbell, Education, EmailOpen, Expand, Eye, FaceID, Factory, File, FileImage, FileSpreadsheet, FilterFunnel, Flag, Food, Fuel, Gem, Globe, Google, Group, Hashtag, History, House, IdCard, Info, Interest, Json, KanbanBoard, Key, KeyRound, Layers2, LayoutDashboard, Lightbulb, Link, Linkedin, List, ListFilter, Loader, LoaderCircle, LockKeyhole, LogOut, Mail, MapPin, MarketPosition, Merge, MessageSquareQuote, Microsoft, More, MoveDrag, NewChat, Newspaper, NotepadText, Package, PartyPopper, Pause, Pencil, Percent, Philanthrophy, Phone, Pin, Play, Plus, Ray, Save, Share2, Shield, Speaker, SquareChartGantt, SquareCheckBig, Stretegy, Swap, Text, TextSearch, Trash, Twitter, Undo, Unlink, User, UserCheck, UserLock, UserPen, UserPlus, UserStar, VerifiedCheck, Wand, WifiOff, WrongAccount

**icon set** — Icon (renders any of 160 glyph names)

**ui kit reference parts** — Frame40 (header bar geometry), SideMenu2 (icon-rail geometry), both lifted verbatim from the Figma shell frames

### Intentional additions

- **`Icon`** — a thin wrapper over the extracted glyph data. The Figma file exposes each glyph as its own component; shipping 177 files would be unusable, so the set is one data module plus one wrapper. No new artwork.

---

## Caveats

- **Satoshi is not supplied and is not on Google Fonts.** The Dayko wordmark falls back to Archivo. Upload the Satoshi files (or confirm a substitute) to make the wordmark correct.
- **The file defines no named Figma text styles**, so `tokens/fig-typography.css` is empty. The type scale in this readme was read off the Typography specimen frame instead.
- **Motion is undefined in the source.** Nothing here is invented.
- Six `SelectLeftDecoration` boolean-operation glyphs could not be decoded from the binary and render as plain boxes.
### Intentionally not built

Every named family in the kit is now built, including the three documentation frames — `ComponentPageHeader`, `ProWarning` and `Frame1984078199` — which live in `components/internal/` because they are Figma library scaffolding rather than product UI.

The icon set is shipped twice, deliberately. `components/glyphs/` holds one component per single-purpose glyph, matching the Figma file's own structure — use these when you want the icon as a component. `assets/icons/icon-data.js` holds all ~160 glyphs as one data module behind a single `Icon` component — use this when you need to pick a glyph by name at runtime. The icon families that carry real variant axes (direction, filled/outline, state) live in `components/icons/` so their props survive.
- Three token names in the Figma variable set are literally `Regular`, `Medium` and `Semibold` (weight strings stored as font-family variables). They are left pointing at those names rather than rewritten.
