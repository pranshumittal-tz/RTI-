import * as React from 'react';
export interface ArrowProps {
  className?: string;
  style?: React.CSSProperties;
  arrow?: "right" | "left" | "down" | "up";
}
export declare const Arrow: React.FC<ArrowProps>;
export default Arrow;
