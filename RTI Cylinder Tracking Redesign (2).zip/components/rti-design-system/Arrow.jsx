// figma node: 1:27 Arrow  (4 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "arrow=" + __venc(p.arrow);

export function Arrow(_p = {}) {
  const props = { ..._p, arrow: _p.arrow ?? "right" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--icon-grey-dark)",
      ...props.style,
    }}>
      <svg width={15.500} height={8.500} viewBox="0 0 15.500 8.500" fill="none" style={{
        position: "absolute",
        left: 4.25,
        top: 7.75,
        width: 15.5,
        height: 8.5,
      }}>
        <path d={"M 0.22 0.22 C 0.513 -0.073 0.987 -0.073 1.28 0.22 L 7.75 6.689 L 14.22 0.22 C 14.513 -0.073 14.987 -0.073 15.28 0.22 C 15.573 0.513 15.573 0.987 15.28 1.28 L 8.28 8.28 C 7.987 8.573 7.513 8.573 7.22 8.28 L 0.22 1.28 C -0.073 0.987 -0.073 0.513 0.22 0.22 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--icon-grey-dark)",
      ...props.style,
    }}>
      <svg width={15.500} height={8.500} viewBox="0 0 15.500 8.500" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0,1,-1,0,16.500,4)",
        transformOrigin: "0 0",
        width: 15.5,
        height: 8.5,
      }}>
        <path d={"M 0.22 0.22 C 0.513 -0.073 0.987 -0.073 1.28 0.22 L 7.75 6.689 L 14.22 0.22 C 14.513 -0.073 14.987 -0.073 15.28 0.22 C 15.573 0.513 15.573 0.987 15.28 1.28 L 8.28 8.28 C 7.987 8.573 7.513 8.573 7.22 8.28 L 0.22 1.28 C -0.073 0.987 -0.073 0.513 0.22 0.22 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--icon-grey-dark)",
      ...props.style,
    }}>
      <svg width={15.500} height={8.500} viewBox="0 0 15.500 8.500" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0,-1,1,0,7.750,19.750)",
        transformOrigin: "0 0",
        width: 15.5,
        height: 8.5,
      }}>
        <path d={"M 0.22 0.22 C 0.513 -0.073 0.987 -0.073 1.28 0.22 L 7.75 6.689 L 14.22 0.22 C 14.513 -0.073 14.987 -0.073 15.28 0.22 C 15.573 0.513 15.573 0.987 15.28 1.28 L 8.28 8.28 C 7.987 8.573 7.513 8.573 7.22 8.28 L 0.22 1.28 C -0.073 0.987 -0.073 0.513 0.22 0.22 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--icon-grey-dark)",
      ...props.style,
    }}>
      <svg width={15.500} height={8.500} viewBox="0 0 15.500 8.500" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(-1,0,0,-1,19.750,16.250)",
        transformOrigin: "0 0",
        width: 15.5,
        height: 8.5,
      }}>
        <path d={"M 1.28 0.22 C 0.987 -0.073 0.513 -0.073 0.22 0.22 M 7.75 6.689 L 1.28 0.22 M 14.22 0.22 L 7.75 6.689 M 15.28 0.22 C 14.987 -0.073 14.513 -0.073 14.22 0.22 M 15.28 1.28 C 15.573 0.987 15.573 0.513 15.28 0.22 M 8.28 8.28 L 15.28 1.28 M 7.22 8.28 C 7.513 8.573 7.987 8.573 8.28 8.28 M 0.22 1.28 L 7.22 8.28 M 0.22 0.22 C -0.073 0.513 -0.073 0.987 0.22 1.28 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
  const __impls = {
    // figma: Arrow=Down
    "arrow=down": __body0,
    // figma: Arrow=Left
    "arrow=left": __body1,
    // figma: Arrow=Right
    "arrow=right": __body2,
    // figma: Arrow=Up
    "arrow=up": __body3,
  };
  return (__impls[__vkey(props)] ?? __body2)();
}
export default Arrow;
