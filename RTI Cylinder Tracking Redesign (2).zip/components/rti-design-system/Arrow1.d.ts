import * as React from 'react';
export interface Arrow1Props {
  className?: string;
  style?: React.CSSProperties;
  arrow?: "right" | "left" | "down" | "up";
}
export declare const Arrow1: React.FC<Arrow1Props>;
export default Arrow1;
