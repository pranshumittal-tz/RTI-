import * as React from 'react';
export interface AvatarProps {
  className?: string;
  style?: React.CSSProperties;
  property1?: "sm" | "md" | "lg";
  /** Text content; defaults to "PM". */
  text1?: string;
}
export declare const Avatar: React.FC<AvatarProps>;
export default Avatar;
