// figma node: 31:1463 Avatar (3 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "property1=" + __venc(p.property1);

export function Avatar(_p = {}) {
  const props = { ..._p, property1: _p.property1 ?? "sm" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      borderRadius: 15,
      backgroundColor: "var(--color-brand-100)",
      boxShadow: "inset 0 0 0 1px var(--color-neutral-0)",
      display: "flex",
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 11,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--color-amber-400)",
        flexShrink: 0,
      }}>{props.text1 ?? "PM"}</span>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 28,
      height: 28,
      borderRadius: 15,
      backgroundColor: "var(--color-brand-100)",
      boxShadow: "inset 0 0 0 1px var(--color-neutral-0)",
      display: "flex",
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "100%",
        color: "var(--color-amber-400)",
        flexShrink: 0,
      }}>{props.text1 ?? "PM"}</span>
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 32,
      borderRadius: 51,
      backgroundColor: "var(--color-brand-100)",
      boxShadow: "inset 0 0 0 1px var(--color-neutral-0)",
      display: "flex",
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--color-amber-400)",
        flexShrink: 0,
      }}>{props.text1 ?? "PM"}</span>
    </div>
  );
  const __impls = {
    // figma: Property 1=Small
    "property1=sm": __body0,
    // figma: Property 1=Medium
    "property1=md": __body1,
    // figma: Property 1=Large
    "property1=lg": __body2,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Avatar;
