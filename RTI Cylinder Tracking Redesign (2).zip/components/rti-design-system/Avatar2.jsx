import { ChevronRight } from './ChevronRight.jsx';
import { Frame1 } from './Frame1.jsx';

// figma node: 36:1503 Avatar
export function Avatar2(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 414,
      backgroundColor: "var(--color-neutral-0)",
      display: "flex",
      flexDirection: "column",
      gap: 27,
      padding: "24px 24px 24px 24px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 382,
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 24,
          lineHeight: "32px",
          color: "var(--color-neutral-800)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>Breadcrumbs</span>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 16,
          lineHeight: "24px",
          color: "var(--color-neutral-600)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>Displays the path to the current resource using a hierarchy of links.</span>
      </div>
      <div style={{
        position: "relative",
        width: 89,
        height: 92,
        overflow: "hidden",
        borderRadius: 5,
        flexShrink: 0,
      }}>
        <div style={{
          position: "absolute",
          left: 20,
          top: 20,
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 16,
            whiteSpace: "nowrap",
            lineHeight: "24px",
            color: "var(--text-tertiary)",
            flexShrink: 0,
          }}>Home</span>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 10,
            padding: "2px 0px 2px 0px",
            alignItems: "center",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexShrink: 0,
          }}>
            <div style={{
                position: "relative",
                width: 12,
                height: 12,
                flexShrink: 0,
                color: "rgb(139,137,131)",
              }}>
              <ChevronRight style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0", color: "rgb(139,137,131)" }} />
            </div>
          </div>
        </div>
        <div style={{
          position: "absolute",
          left: 20,
          top: 56,
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-primary)",
            flexShrink: 0,
          }}>Home</span>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 10,
            padding: "2px 0px 2px 0px",
            alignItems: "center",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexShrink: 0,
          }}>
            <div style={{
                position: "relative",
                width: 12,
                height: 12,
                flexShrink: 0,
                color: "var(--text-primary)",
              }}>
              <ChevronRight style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0", color: "var(--text-primary)" }} />
            </div>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: 12,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 16,
          lineHeight: "24px",
          color: "var(--color-neutral-800)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>Example</span>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <Frame1
            style={{ position: "relative", flexShrink: 0 }}
            property1={"default"}
          />
          <Frame1
            style={{ position: "relative", width: 85, flexShrink: 0 }}
            text1={"Components"}
            property1={"default"}
          />
          <Frame1
            style={{ position: "relative", width: 66, flexShrink: 0 }}
            text1={"Breadcrumb"}
            property1={"active"}
          />
        </div>
      </div>
    </div>
  );
}
export default Avatar2;
