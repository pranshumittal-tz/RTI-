import * as React from 'react';
export interface AvatarGroupProps {
  className?: string;
  style?: React.CSSProperties;
  /** Text content; defaults to "PM". */
  text1?: string;
  /** Text content; defaults to "SB". */
  text2?: string;
  /** Text content; defaults to "KS". */
  text3?: string;
}
export declare const AvatarGroup: React.FC<AvatarGroupProps>;
export default AvatarGroup;
