// figma node: 31:1475 Avatar Group
export function AvatarGroup(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: -10,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 28,
        borderRadius: 15,
        backgroundColor: "var(--color-brand-100)",
        boxShadow: "inset 0 0 0 1px var(--color-neutral-0)",
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          textAlign: "center",
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--color-amber-400)",
          flexShrink: 0,
        }}>{props.text1 ?? "PM"}</span>
      </div>
      <div style={{
        position: "relative",
        width: 28,
        borderRadius: 15,
        backgroundColor: "var(--color-brand-100)",
        boxShadow: "inset 0 0 0 1px var(--color-neutral-0)",
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          textAlign: "center",
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--color-amber-400)",
          flexShrink: 0,
        }}>{props.text2 ?? "SB"}</span>
      </div>
      <div style={{
        position: "relative",
        width: 28,
        borderRadius: 15,
        backgroundColor: "var(--color-brand-100)",
        boxShadow: "inset 0 0 0 1px var(--color-neutral-0)",
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          textAlign: "center",
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--color-amber-400)",
          flexShrink: 0,
        }}>{props.text3 ?? "KS"}</span>
      </div>
    </div>
  );
}
export default AvatarGroup;
