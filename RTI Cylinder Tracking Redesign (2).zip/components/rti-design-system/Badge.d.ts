import * as React from 'react';
export interface BadgeProps {
  className?: string;
  style?: React.CSSProperties;
  state?: "default" | "secondary" | "destructive" | "outline" | "ghost";
  leftIcon?: boolean;
  rightIcon?: boolean;
  /** Text content; defaults to "Default". */
  text1?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
}
export declare const Badge: React.FC<BadgeProps>;
export default Badge;
