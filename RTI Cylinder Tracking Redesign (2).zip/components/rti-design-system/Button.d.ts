import * as React from 'react';
export interface ButtonProps {
  className?: string;
  style?: React.CSSProperties;
  rightIcon?: boolean;
  type?: "primary" | "ghost" | "hyperlink" | "secondary" | "tertiary" | "danger";
  leftIcon?: boolean;
  state?: "disabled" | "default" | "hover";
  size?: "lg" | "md" | "sm";
  /** Text content; defaults to "Label". */
  text1?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
}
export declare const Button: React.FC<ButtonProps>;
export default Button;
