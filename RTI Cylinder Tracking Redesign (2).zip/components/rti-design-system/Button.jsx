import { Arrow } from './Arrow.jsx';
import { Delete } from './Delete.jsx';

// figma node: 1:45 Button (42 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "type=" + __venc(p.type) + '|' + "state=" + __venc(p.state) + '|' + "size=" + __venc(p.size);

export function Button(_p = {}) {
  const props = { ..._p, rightIcon: _p.rightIcon ?? true, type: _p.type ?? "primary", leftIcon: _p.leftIcon ?? true, state: _p.state ?? "disabled", size: _p.size ?? "lg" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 148,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 148,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-brand)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-white)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 130,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-brand)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-white)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-white)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-white)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 130,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-brand)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-white)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: 130,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-brand-strong)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-white)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: 130,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body6 = () => (
    <div className={props.className} style={{
      width: 130,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-brand-strong)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-white)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-white)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-white)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body7 = () => (
    <div className={props.className} style={{
      width: 130,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body8 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-brand)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body9 = () => (
    <div className={props.className} style={{
      width: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-brand)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body10 = () => (
    <div className={props.className} style={{
      width: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
          color: "var(--colors-text-text-brand)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-brand)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
          color: "var(--colors-text-text-brand)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body11 = () => (
    <div className={props.className} style={{
      width: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
          color: "var(--colors-text-text-brand-dark)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-brand-dark)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
          color: "var(--colors-text-text-brand-dark)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body12 = () => (
    <div className={props.className} style={{
      width: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body13 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-brand)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-brand)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-brand)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body14 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "rgb(8,73,40)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-brand-dark)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "rgb(8,73,40)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body15 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body16 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "rgb(8,73,40)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-brand-dark)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "rgb(8,73,40)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body17 = () => (
    <div className={props.className} style={{
      width: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "rgb(8,73,40)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-brand-dark)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "rgb(8,73,40)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body18 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body19 = () => (
    <div className={props.className} style={{
      width: 150,
      borderRadius: 12,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body20 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-secondary)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-brand)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body21 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-white)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-heading)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body22 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-white)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-heading)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-heading)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-heading)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body23 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-white)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-heading)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body24 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-neutral-secondary)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-heading)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body25 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-neutral-secondary)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body26 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon1 ?? <Delete />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-error)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body27 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-error)",
        }}>{props.icon1 ?? <Delete style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-error)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-error)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body28 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 8,
      boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon1 ?? <Delete />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-error)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body29 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-error-500)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon1 ?? <Delete />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-error)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body30 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-error-500)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-error)",
        }}>{props.icon1 ?? <Delete style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-error)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-error)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body31 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 8,
      backgroundColor: "var(--colors-error-500)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon1 ?? <Delete />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-error)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-error)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body32 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-light)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Delete />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body33 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-light)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Delete style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body34 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 8,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-light)",
      display: "flex",
      flexDirection: "row",
      padding: "14px 16px 14px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-14) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-14) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Delete />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 12,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "16px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body35 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-neutral-secondary)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-heading)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-heading)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body36 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-neutral-secondary)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-heading)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-heading)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-heading)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body37 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-neutral-secondary)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body38 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-neutral-secondary)",
      boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 14,
          height: 14,
          flexShrink: 0,
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body39 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-secondary-strong)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-brand)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-brand)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body40 = () => (
    <div className={props.className} style={{
      width: 148,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-brand-strong)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-white)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-white)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __body41 = () => (
    <div className={props.className} style={{
      width: 150,
      minWidth: 150,
      borderRadius: 12,
      backgroundColor: "var(--colors-bg-bg-disabled)",
      display: "flex",
      flexDirection: "row",
      padding: "12px 16px 12px 16px",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      paddingLeft: "calc(var(--spacing-16) * 1px)",
      paddingTop: "calc(var(--spacing-12) * 1px)",
      paddingRight: "calc(var(--spacing-16) * 1px)",
      paddingBottom: "calc(var(--spacing-12) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon1 ?? <Arrow arrow={"left"} />}</div>
      )}
      <span style={{
        position: "relative",
        fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: "22px",
        color: "var(--colors-text-text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Label"}</span>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 20,
          flexShrink: 0,
          alignSelf: "stretch",
          height: "auto",
          color: "var(--colors-text-text-disabled)",
        }}>{props.icon2 ?? <Arrow arrow={"right"} />}</div>
      )}
    </div>
  );
  const __impls = {
    // figma: Type=Primary, State=Disabled, Size=Large
    "type=primary|state=disabled|size=lg": __body0,
    // figma: Type=Primary, State=Default, Size=Large
    "type=primary|state=default|size=lg": __body1,
    // figma: Type=Primary, State=Default, Size=Medium
    "type=primary|state=default|size=md": __body2,
    // figma: Type=Primary, State=Default, Size=Small
    "type=primary|state=default|size=sm": __body3,
    // figma: Type=Primary, State=Hover, Size=Small
    "type=primary|state=hover|size=sm": __body4,
    // figma: Type=Primary, State=Disabled, Size=Small
    "type=primary|state=disabled|size=sm": __body5,
    // figma: Type=Primary, State=Hover, Size=Medium
    "type=primary|state=hover|size=md": __body6,
    // figma: Type=Primary, State=Disabled, Size=Medium
    "type=primary|state=disabled|size=md": __body7,
    // figma: Type=Ghost, State=Default, Size=Large
    "type=ghost|state=default|size=lg": __body8,
    // figma: Type=Hyperlink, State=Default, Size=Large
    "type=hyperlink|state=default|size=lg": __body9,
    // figma: Type=Hyperlink, State=Default, Size=Medium
    "type=hyperlink|state=default|size=md": __body10,
    // figma: Type=Hyperlink, State=Hover, Size=Medium
    "type=hyperlink|state=hover|size=md": __body11,
    // figma: Type=Hyperlink, State=Disabled, Size=Medium
    "type=hyperlink|state=disabled|size=md": __body12,
    // figma: Type=Ghost, State=Default, Size=Medium
    "type=ghost|state=default|size=md": __body13,
    // figma: Type=Ghost, State=Hover, Size=Medium
    "type=ghost|state=hover|size=md": __body14,
    // figma: Type=Ghost, State=Disabled, Size=Medium
    "type=ghost|state=disabled|size=md": __body15,
    // figma: Type=Ghost, State=Hover, Size=Large
    "type=ghost|state=hover|size=lg": __body16,
    // figma: Type=Hyperlink, State=Hover, Size=Large
    "type=hyperlink|state=hover|size=lg": __body17,
    // figma: Type=Ghost, State=Disabled, Size=Large
    "type=ghost|state=disabled|size=lg": __body18,
    // figma: Type=Hyperlink, State=Disabled, Size=Large
    "type=hyperlink|state=disabled|size=lg": __body19,
    // figma: Type=Secondary, State=Default, Size=Large
    "type=secondary|state=default|size=lg": __body20,
    // figma: Type=Tertiary, State=Default, Size=Large
    "type=tertiary|state=default|size=lg": __body21,
    // figma: Type=Tertiary, State=Default, Size=Medium
    "type=tertiary|state=default|size=md": __body22,
    // figma: Type=Tertiary, State=Default, Size=Small
    "type=tertiary|state=default|size=sm": __body23,
    // figma: Type=Tertiary, State=Hover, Size=Small
    "type=tertiary|state=hover|size=sm": __body24,
    // figma: Type=Tertiary, State=Disabled, Size=Small
    "type=tertiary|state=disabled|size=sm": __body25,
    // figma: Type=Danger, State=Default, Size=Large
    "type=danger|state=default|size=lg": __body26,
    // figma: Type=Danger, State=Default, Size=Medium
    "type=danger|state=default|size=md": __body27,
    // figma: Type=Danger, State=Default, Size=Small
    "type=danger|state=default|size=sm": __body28,
    // figma: Type=Danger, State=Hover, Size=Large
    "type=danger|state=hover|size=lg": __body29,
    // figma: Type=Danger, State=Hover, Size=Medium
    "type=danger|state=hover|size=md": __body30,
    // figma: Type=Danger, State=Hover, Size=Small
    "type=danger|state=hover|size=sm": __body31,
    // figma: Type=Danger, State=Disabled, Size=Large
    "type=danger|state=disabled|size=lg": __body32,
    // figma: Type=Danger, State=Disabled, Size=Medium
    "type=danger|state=disabled|size=md": __body33,
    // figma: Type=Danger, State=Disabled, Size=Small
    "type=danger|state=disabled|size=sm": __body34,
    // figma: Type=Tertiary, State=Hover, Size=Large
    "type=tertiary|state=hover|size=lg": __body35,
    // figma: Type=Tertiary, State=Hover, Size=Medium
    "type=tertiary|state=hover|size=md": __body36,
    // figma: Type=Tertiary, State=Disabled, Size=Large
    "type=tertiary|state=disabled|size=lg": __body37,
    // figma: Type=Tertiary, State=Disabled, Size=Medium
    "type=tertiary|state=disabled|size=md": __body38,
    // figma: Type=Secondary, State=Hover, Size=Large
    "type=secondary|state=hover|size=lg": __body39,
    // figma: Type=Primary, State=Hover, Size=Large
    "type=primary|state=hover|size=lg": __body40,
    // figma: Type=Secondary, State=Disabled, Size=Large
    "type=secondary|state=disabled|size=lg": __body41,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Button;
