import * as React from 'react';
export interface Button3Props {
  className?: string;
  style?: React.CSSProperties;
  rightIcon?: boolean;
  state?: "default" | "hover" | "focused" | "disabled";
  leftIcon?: boolean;
  variant?: "primary" | "tertiary" | "ghost" | "destructive" | "secondary";
  /** Text content; defaults to "Buttons". */
  text1?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
}
export declare const Button3: React.FC<Button3Props>;
export default Button3;
