import { ChevronDown } from './ChevronDown.jsx';

// figma node: 53:7437 Button (20 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "state=" + __venc(p.state) + '|' + "variant=" + __venc(p.variant);

export function Button3(_p = {}) {
  const props = { ..._p, rightIcon: _p.rightIcon ?? false, state: _p.state ?? "default", leftIcon: _p.leftIcon ?? false, variant: _p.variant ?? "primary" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-brand-500)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 20,
        whiteSpace: "nowrap",
        lineHeight: "28px",
        color: "var(--color-neutral-0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-neutral-0)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-brand-100)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--color-brand-500)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-brand-500)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-neutral-50)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "rgb(182,180,175)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      overflow: "hidden",
      borderRadius: 8,
      backgroundColor: "var(--color-brand-100)",
      boxShadow: "0 0 0 1px var(--border-color-focus), 0px 0px 0px 3px rgba(248,208,184,0.45)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--color-brand-500)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-brand-500)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-brand-200)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--color-brand-500)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-brand-500)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-surface)",
      boxShadow: "0 0 0 1px var(--border-color-default)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body6 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-red-100)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--status-error-text)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--status-error-text)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--status-error-text)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body7 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-red-100)",
      boxShadow: "0 0 0 1px var(--color-red-100)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--status-error-text)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--status-error-text)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--status-error-text)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body8 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-red-50)",
      boxShadow: "0 0 0 1px var(--color-red-200)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--status-error-text)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--status-error-text)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--status-error-text)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body9 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-red-50)",
      boxShadow: "0 0 0 1px var(--status-error-border)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-red-200)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        opacity: 0.5,
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--color-red-200)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-red-200)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body10 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body11 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 9px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "rgb(182,180,175)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "rgb(182,180,175)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body12 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-neutral-50)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body13 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      overflow: "hidden",
      borderRadius: 8,
      backgroundColor: "var(--color-neutral-50)",
      boxShadow: "0 0 0 1px var(--border-color-default), 0px 0px 0px 3px rgb(225,225,225)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body14 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-surface)",
      boxShadow: "0 0 0 1px var(--border-color-default)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "rgb(182,180,175)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-disabled)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "rgb(182,180,175)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body15 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-neutral-50)",
      boxShadow: "0 0 0 1px var(--border-color-default)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body16 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      overflow: "hidden",
      borderRadius: 8,
      backgroundColor: "var(--color-neutral-0)",
      boxShadow: "0 0 0 1px var(--border-color-default), 0px 0px 0px 3px rgb(225,225,225)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--text-primary)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body17 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      overflow: "hidden",
      borderRadius: 8,
      backgroundColor: "var(--color-brand-500)",
      boxShadow: "0px 0px 0px 3px rgb(248,208,184)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--color-neutral-0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-neutral-0)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body18 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--color-brand-600)",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      padding: "8px 12px 8px 12px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--color-neutral-0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Buttons"}</span>
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
          color: "var(--color-neutral-0)",
        }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.600, 0.600)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __impls = {
    // figma: State=Default, Variant=Primary
    "state=default|variant=primary": __body0,
    // figma: State=Default, Variant=Secondary
    "state=default|variant=secondary": __body1,
    // figma: State=Disabled, Variant=Secondary
    "state=disabled|variant=secondary": __body2,
    // figma: State=Focused, Variant=Secondary
    "state=focused|variant=secondary": __body3,
    // figma: State=Hover, Variant=Secondary
    "state=hover|variant=secondary": __body4,
    // figma: State=Default, Variant=Tertiary
    "state=default|variant=tertiary": __body5,
    // figma: State=Default, Variant=Destructive
    "state=default|variant=destructive": __body6,
    // figma: State=Hover, Variant=Destructive
    "state=hover|variant=destructive": __body7,
    // figma: State=Focused, Variant=Destructive
    "state=focused|variant=destructive": __body8,
    // figma: State=Disabled, Variant=Destructive
    "state=disabled|variant=destructive": __body9,
    // figma: State=Default, Variant=Ghost
    "state=default|variant=ghost": __body10,
    // figma: State=Disabled, Variant=Ghost
    "state=disabled|variant=ghost": __body11,
    // figma: State=Hover, Variant=Ghost
    "state=hover|variant=ghost": __body12,
    // figma: State=Focused, Variant=Ghost
    "state=focused|variant=ghost": __body13,
    // figma: State=Disabled, Variant=Tertiary
    "state=disabled|variant=tertiary": __body14,
    // figma: State=Hover, Variant=Tertiary
    "state=hover|variant=tertiary": __body15,
    // figma: State=Focused, Variant=Tertiary
    "state=focused|variant=tertiary": __body16,
    // figma: State=Disabled, Variant=Primary
    "state=disabled|variant=primary": __body2,
    // figma: State=Focused, Variant=Primary
    "state=focused|variant=primary": __body17,
    // figma: State=Hover, Variant=Primary
    "state=hover|variant=primary": __body18,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Button3;
