import * as React from 'react';
export interface ButtonGroupButtonProps {
  className?: string;
  style?: React.CSSProperties;
  leftIcon?: boolean;
  variant?: "outline" | "secondary" | "ghost";
  roundness?: "default" | "rounded";
  rightIcon?: boolean;
  size?: "sm" | "default" | "lg";
  position?: "single" | "left" | "right" | "middle";
  state?: "default" | "hover" | "focus" | "disabled";
  /** Text content; defaults to "Button". */
  text1?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
}
export declare const ButtonGroupButton: React.FC<ButtonGroupButtonProps>;
export default ButtonGroupButton;
