import { LucideCircleFadingPlus } from './LucideCircleFadingPlus.jsx';

// figma node: 47:4072 ButtonGroupButton (144 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "variant=" + __venc(p.variant) + '|' + "roundness=" + __venc(p.roundness) + '|' + "size=" + __venc(p.size) + '|' + "position=" + __venc(p.position) + '|' + "state=" + __venc(p.state);

export function ButtonGroupButton(_p = {}) {
  const props = { ..._p, leftIcon: _p.leftIcon ?? false, variant: _p.variant ?? "outline", roundness: _p.roundness ?? "default", rightIcon: _p.rightIcon ?? false, size: _p.size ?? "sm", position: _p.position ?? "single", state: _p.state ?? "default" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body6 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body7 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body8 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body9 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body10 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body11 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body12 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body13 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body14 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body15 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body16 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body17 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body18 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body19 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body20 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body21 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body22 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body23 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body24 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body25 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body26 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: "6px 0px 0px 6px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body27 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body28 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body29 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body30 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body31 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body32 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: "10px 0px 0px 10px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body33 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body34 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body35 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body36 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body37 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body38 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body39 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body40 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body41 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body42 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body43 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 9999,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body44 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body45 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body46 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body47 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 9999,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body48 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body49 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body50 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body51 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 9999,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body52 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body53 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: 9999,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body54 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 6,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body55 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 6,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body56 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: 6,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body57 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: 6,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body58 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 10,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body59 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 10,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body60 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: 10,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body61 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: 10,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body62 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 10,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body63 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 10,
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body64 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: 10,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body65 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: 10,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body66 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body67 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body68 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body69 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body70 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body71 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body72 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body73 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body74 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: 9999,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body75 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 6,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body76 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: 6,
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body77 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: 6,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body78 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 10,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body79 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: 10,
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body80 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: 10,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body81 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 10,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body82 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: 10,
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body83 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: 10,
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body84 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body85 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body86 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body87 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body88 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body89 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body90 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body91 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body92 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body93 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body94 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body95 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body96 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body97 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      overflow: "hidden",
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body98 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: "0px 6px 6px 0px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body99 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body100 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      overflow: "hidden",
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body101 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body102 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body103 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      overflow: "hidden",
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--secondary)",
      borderTop: "1px solid var(--ring)",
      borderRight: "1px solid var(--ring)",
      borderBottom: "1px solid var(--ring)",
      borderLeft: "1px solid var(--ring)",
      boxShadow: "0px 0px 0px 3px rgba(161,161,161,0.5)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body104 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: "0px 10px 10px 0px",
      backgroundColor: "var(--secondary)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--secondary-foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body105 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 9999,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body106 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 9999,
      backgroundColor: "var(--muted)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body107 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: 9999,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body108 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 9999,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body109 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 9999,
      backgroundColor: "var(--muted)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body110 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: 9999,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body111 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 9999,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body112 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 9999,
      backgroundColor: "var(--muted)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body113 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: 9999,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body114 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 6,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body115 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      borderRadius: 6,
      backgroundColor: "var(--muted)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body116 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 28,
      opacity: 0.5,
      borderRadius: 6,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 12,
          height: 12,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body117 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 10,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body118 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      borderRadius: 10,
      backgroundColor: "var(--muted)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body119 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 32,
      opacity: 0.5,
      borderRadius: 10,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body120 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 10,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body121 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      borderRadius: 10,
      backgroundColor: "var(--muted)",
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __body122 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      height: 36,
      opacity: 0.5,
      borderRadius: 10,
      display: "flex",
      flexDirection: "row",
      gap: 4,
      padding: "0px 10px 0px 10px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      {props.leftIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon1 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--foreground)",
          flexShrink: 0,
        }}>{props.text1 ?? "Button"}</span>
      </div>
      {props.rightIcon && (
      <div style={{
          position: "relative",
          width: 16,
          height: 16,
          flexShrink: 0,
        }}>{props.icon2 ?? <LucideCircleFadingPlus style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
      )}
    </div>
  );
  const __impls = {
    // figma: Variant=Outline, Size=sm, State=Default, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=left|state=default": __body0,
    // figma: Variant=Outline, Size=sm, State=Hover, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=left|state=hover": __body1,
    // figma: Variant=Outline, Size=sm, State=Focus, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=left|state=focus": __body2,
    // figma: Variant=Outline, Size=sm, State=Disabled, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=left|state=disabled": __body3,
    // figma: Variant=Outline, Size=default, State=Default, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=default|position=left|state=default": __body4,
    // figma: Variant=Outline, Size=default, State=Hover, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=default|position=left|state=hover": __body5,
    // figma: Variant=Outline, Size=default, State=Focus, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=default|position=left|state=focus": __body6,
    // figma: Variant=Outline, Size=default, State=Disabled, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=default|position=left|state=disabled": __body7,
    // figma: Variant=Outline, Size=large, State=Default, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=left|state=default": __body8,
    // figma: Variant=Outline, Size=large, State=Hover, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=left|state=hover": __body9,
    // figma: Variant=Outline, Size=large, State=Focus, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=left|state=focus": __body10,
    // figma: Variant=Outline, Size=large, State=Disabled, Position=Left, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=left|state=disabled": __body11,
    // figma: Variant=Outline, Size=sm, State=Default, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=middle|state=default": __body12,
    // figma: Variant=Outline, Size=sm, State=Hover, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=middle|state=hover": __body13,
    // figma: Variant=Outline, Size=sm, State=Focus, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=middle|state=focus": __body14,
    // figma: Variant=Outline, Size=sm, State=Disabled, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=middle|state=disabled": __body15,
    // figma: Variant=Outline, Size=default, State=Default, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=default|position=middle|state=default": __body16,
    // figma: Variant=Outline, Size=default, State=Hover, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=default|position=middle|state=hover": __body17,
    // figma: Variant=Outline, Size=default, State=Focus, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=default|position=middle|state=focus": __body18,
    // figma: Variant=Outline, Size=default, State=Disabled, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=default|position=middle|state=disabled": __body19,
    // figma: Variant=Outline, Size=large, State=Default, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=middle|state=default": __body20,
    // figma: Variant=Outline, Size=large, State=Hover, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=middle|state=hover": __body21,
    // figma: Variant=Outline, Size=large, State=Focus, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=middle|state=focus": __body22,
    // figma: Variant=Outline, Size=large, State=Disabled, Position=Middle, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=middle|state=disabled": __body23,
    // figma: Variant=Secondary, Size=sm, State=Default, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=left|state=default": __body24,
    // figma: Variant=Secondary, Size=sm, State=Hover, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=left|state=hover": __body24,
    // figma: Variant=Secondary, Size=sm, State=Focus, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=left|state=focus": __body25,
    // figma: Variant=Secondary, Size=sm, State=Disabled, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=left|state=disabled": __body26,
    // figma: Variant=Secondary, Size=default, State=Default, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=left|state=default": __body27,
    // figma: Variant=Secondary, Size=default, State=Hover, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=left|state=hover": __body27,
    // figma: Variant=Secondary, Size=default, State=Focus, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=left|state=focus": __body28,
    // figma: Variant=Secondary, Size=default, State=Disabled, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=left|state=disabled": __body29,
    // figma: Variant=Secondary, Size=large, State=Default, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=left|state=default": __body30,
    // figma: Variant=Secondary, Size=large, State=Hover, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=left|state=hover": __body30,
    // figma: Variant=Secondary, Size=large, State=Focus, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=left|state=focus": __body31,
    // figma: Variant=Secondary, Size=large, State=Disabled, Position=Left, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=left|state=disabled": __body32,
    // figma: Variant=Secondary, Size=sm, State=Default, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=middle|state=default": __body33,
    // figma: Variant=Secondary, Size=sm, State=Hover, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=middle|state=hover": __body33,
    // figma: Variant=Secondary, Size=sm, State=Focus, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=middle|state=focus": __body34,
    // figma: Variant=Secondary, Size=sm, State=Disabled, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=middle|state=disabled": __body35,
    // figma: Variant=Secondary, Size=default, State=Default, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=middle|state=default": __body36,
    // figma: Variant=Secondary, Size=default, State=Hover, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=middle|state=hover": __body36,
    // figma: Variant=Secondary, Size=default, State=Focus, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=middle|state=focus": __body37,
    // figma: Variant=Secondary, Size=default, State=Disabled, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=middle|state=disabled": __body38,
    // figma: Variant=Secondary, Size=large, State=Default, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=middle|state=default": __body39,
    // figma: Variant=Secondary, Size=large, State=Hover, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=middle|state=hover": __body39,
    // figma: Variant=Secondary, Size=large, State=Focus, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=middle|state=focus": __body40,
    // figma: Variant=Secondary, Size=large, State=Disabled, Position=Middle, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=middle|state=disabled": __body41,
    // figma: Variant=Outline, Size=sm, State=Default, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=sm|position=single|state=default": __body42,
    // figma: Variant=Outline, Size=sm, State=Hover, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=sm|position=single|state=hover": __body43,
    // figma: Variant=Outline, Size=sm, State=Focus, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=sm|position=single|state=focus": __body44,
    // figma: Variant=Outline, Size=sm, State=Disabled, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=sm|position=single|state=disabled": __body45,
    // figma: Variant=Outline, Size=default, State=Default, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=default|position=single|state=default": __body46,
    // figma: Variant=Outline, Size=default, State=Hover, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=default|position=single|state=hover": __body47,
    // figma: Variant=Outline, Size=default, State=Focus, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=default|position=single|state=focus": __body48,
    // figma: Variant=Outline, Size=default, State=Disabled, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=default|position=single|state=disabled": __body49,
    // figma: Variant=Outline, Size=large, State=Default, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=lg|position=single|state=default": __body50,
    // figma: Variant=Outline, Size=large, State=Hover, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=lg|position=single|state=hover": __body51,
    // figma: Variant=Outline, Size=large, State=Focus, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=lg|position=single|state=focus": __body52,
    // figma: Variant=Outline, Size=large, State=Disabled, Position=Single, Roundness=Rounded
    "variant=outline|roundness=rounded|size=lg|position=single|state=disabled": __body53,
    // figma: Variant=Outline, Size=sm, State=Default, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=single|state=default": __body54,
    // figma: Variant=Outline, Size=sm, State=Hover, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=single|state=hover": __body55,
    // figma: Variant=Outline, Size=sm, State=Focus, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=single|state=focus": __body56,
    // figma: Variant=Outline, Size=sm, State=Disabled, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=single|state=disabled": __body57,
    // figma: Variant=Outline, Size=default, State=Default, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=default|position=single|state=default": __body58,
    // figma: Variant=Outline, Size=default, State=Hover, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=default|position=single|state=hover": __body59,
    // figma: Variant=Outline, Size=default, State=Focus, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=default|position=single|state=focus": __body60,
    // figma: Variant=Outline, Size=default, State=Disabled, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=default|position=single|state=disabled": __body61,
    // figma: Variant=Outline, Size=large, State=Default, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=single|state=default": __body62,
    // figma: Variant=Outline, Size=large, State=Hover, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=single|state=hover": __body63,
    // figma: Variant=Outline, Size=large, State=Focus, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=single|state=focus": __body64,
    // figma: Variant=Outline, Size=large, State=Disabled, Position=Single, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=single|state=disabled": __body65,
    // figma: Variant=Secondary, Size=sm, State=Default, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=sm|position=single|state=default": __body66,
    // figma: Variant=Secondary, Size=sm, State=Hover, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=sm|position=single|state=hover": __body66,
    // figma: Variant=Secondary, Size=sm, State=Focus, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=sm|position=single|state=focus": __body67,
    // figma: Variant=Secondary, Size=sm, State=Disabled, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=sm|position=single|state=disabled": __body68,
    // figma: Variant=Secondary, Size=default, State=Default, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=default|position=single|state=default": __body69,
    // figma: Variant=Secondary, Size=default, State=Hover, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=default|position=single|state=hover": __body69,
    // figma: Variant=Secondary, Size=default, State=Focus, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=default|position=single|state=focus": __body70,
    // figma: Variant=Secondary, Size=default, State=Disabled, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=default|position=single|state=disabled": __body71,
    // figma: Variant=Secondary, Size=large, State=Default, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=lg|position=single|state=default": __body72,
    // figma: Variant=Secondary, Size=large, State=Hover, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=lg|position=single|state=hover": __body72,
    // figma: Variant=Secondary, Size=large, State=Focus, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=lg|position=single|state=focus": __body73,
    // figma: Variant=Secondary, Size=large, State=Disabled, Position=Single, Roundness=Rounded
    "variant=secondary|roundness=rounded|size=lg|position=single|state=disabled": __body74,
    // figma: Variant=Secondary, Size=sm, State=Default, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=single|state=default": __body75,
    // figma: Variant=Secondary, Size=sm, State=Hover, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=single|state=hover": __body75,
    // figma: Variant=Secondary, Size=sm, State=Focus, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=single|state=focus": __body76,
    // figma: Variant=Secondary, Size=sm, State=Disabled, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=single|state=disabled": __body77,
    // figma: Variant=Secondary, Size=default, State=Default, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=single|state=default": __body78,
    // figma: Variant=Secondary, Size=default, State=Hover, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=single|state=hover": __body78,
    // figma: Variant=Secondary, Size=default, State=Focus, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=single|state=focus": __body79,
    // figma: Variant=Secondary, Size=default, State=Disabled, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=single|state=disabled": __body80,
    // figma: Variant=Secondary, Size=large, State=Default, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=single|state=default": __body81,
    // figma: Variant=Secondary, Size=large, State=Hover, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=single|state=hover": __body81,
    // figma: Variant=Secondary, Size=large, State=Focus, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=single|state=focus": __body82,
    // figma: Variant=Secondary, Size=large, State=Disabled, Position=Single, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=single|state=disabled": __body83,
    // figma: Variant=Outline, Size=sm, State=Default, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=right|state=default": __body84,
    // figma: Variant=Outline, Size=sm, State=Hover, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=right|state=hover": __body85,
    // figma: Variant=Outline, Size=sm, State=Focus, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=right|state=focus": __body86,
    // figma: Variant=Outline, Size=sm, State=Disabled, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=sm|position=right|state=disabled": __body87,
    // figma: Variant=Outline, Size=default, State=Default, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=default|position=right|state=default": __body88,
    // figma: Variant=Outline, Size=default, State=Hover, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=default|position=right|state=hover": __body89,
    // figma: Variant=Outline, Size=default, State=Focus, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=default|position=right|state=focus": __body90,
    // figma: Variant=Outline, Size=default, State=Disabled, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=default|position=right|state=disabled": __body91,
    // figma: Variant=Outline, Size=large, State=Default, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=right|state=default": __body92,
    // figma: Variant=Outline, Size=large, State=Hover, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=right|state=hover": __body93,
    // figma: Variant=Outline, Size=large, State=Focus, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=right|state=focus": __body94,
    // figma: Variant=Outline, Size=large, State=Disabled, Position=Right, Roundness=Default
    "variant=outline|roundness=default|size=lg|position=right|state=disabled": __body95,
    // figma: Variant=Secondary, Size=sm, State=Default, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=right|state=default": __body96,
    // figma: Variant=Secondary, Size=sm, State=Hover, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=right|state=hover": __body96,
    // figma: Variant=Secondary, Size=sm, State=Focus, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=right|state=focus": __body97,
    // figma: Variant=Secondary, Size=sm, State=Disabled, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=sm|position=right|state=disabled": __body98,
    // figma: Variant=Secondary, Size=default, State=Default, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=right|state=default": __body99,
    // figma: Variant=Secondary, Size=default, State=Hover, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=right|state=hover": __body99,
    // figma: Variant=Secondary, Size=default, State=Focus, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=right|state=focus": __body100,
    // figma: Variant=Secondary, Size=default, State=Disabled, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=default|position=right|state=disabled": __body101,
    // figma: Variant=Secondary, Size=large, State=Default, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=right|state=default": __body102,
    // figma: Variant=Secondary, Size=large, State=Hover, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=right|state=hover": __body102,
    // figma: Variant=Secondary, Size=large, State=Focus, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=right|state=focus": __body103,
    // figma: Variant=Secondary, Size=large, State=Disabled, Position=Right, Roundness=Default
    "variant=secondary|roundness=default|size=lg|position=right|state=disabled": __body104,
    // figma: Variant=Ghost, Size=sm, State=Default, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=sm|position=single|state=default": __body105,
    // figma: Variant=Ghost, Size=sm, State=Hover, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=sm|position=single|state=hover": __body106,
    // figma: Variant=Ghost, Size=sm, State=Focus, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=sm|position=single|state=focus": __body44,
    // figma: Variant=Ghost, Size=sm, State=Disabled, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=sm|position=single|state=disabled": __body107,
    // figma: Variant=Ghost, Size=default, State=Default, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=default|position=single|state=default": __body108,
    // figma: Variant=Ghost, Size=default, State=Hover, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=default|position=single|state=hover": __body109,
    // figma: Variant=Ghost, Size=default, State=Focus, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=default|position=single|state=focus": __body48,
    // figma: Variant=Ghost, Size=default, State=Disabled, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=default|position=single|state=disabled": __body110,
    // figma: Variant=Ghost, Size=large, State=Default, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=lg|position=single|state=default": __body111,
    // figma: Variant=Ghost, Size=large, State=Hover, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=lg|position=single|state=hover": __body112,
    // figma: Variant=Ghost, Size=large, State=Focus, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=lg|position=single|state=focus": __body52,
    // figma: Variant=Ghost, Size=large, State=Disabled, Position=Single, Roundness=Rounded
    "variant=ghost|roundness=rounded|size=lg|position=single|state=disabled": __body113,
    // figma: Variant=Ghost, Size=sm, State=Default, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=sm|position=single|state=default": __body114,
    // figma: Variant=Ghost, Size=sm, State=Hover, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=sm|position=single|state=hover": __body115,
    // figma: Variant=Ghost, Size=sm, State=Focus, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=sm|position=single|state=focus": __body56,
    // figma: Variant=Ghost, Size=sm, State=Disabled, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=sm|position=single|state=disabled": __body116,
    // figma: Variant=Ghost, Size=default, State=Default, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=default|position=single|state=default": __body117,
    // figma: Variant=Ghost, Size=default, State=Hover, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=default|position=single|state=hover": __body118,
    // figma: Variant=Ghost, Size=default, State=Focus, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=default|position=single|state=focus": __body60,
    // figma: Variant=Ghost, Size=default, State=Disabled, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=default|position=single|state=disabled": __body119,
    // figma: Variant=Ghost, Size=large, State=Default, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=lg|position=single|state=default": __body120,
    // figma: Variant=Ghost, Size=large, State=Hover, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=lg|position=single|state=hover": __body121,
    // figma: Variant=Ghost, Size=large, State=Focus, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=lg|position=single|state=focus": __body64,
    // figma: Variant=Ghost, Size=large, State=Disabled, Position=Single, Roundness=Default
    "variant=ghost|roundness=default|size=lg|position=single|state=disabled": __body122,
  };
  return (__impls[__vkey(props)] ?? __body54)();
}
export default ButtonGroupButton;
