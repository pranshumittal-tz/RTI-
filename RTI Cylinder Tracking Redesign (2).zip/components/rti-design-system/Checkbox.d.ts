import * as React from 'react';
export interface CheckboxProps {
  className?: string;
  style?: React.CSSProperties;
  interaction?: "default" | "focus" | "disabled" | "invalid";
  dataState?: "checked" | "unchecked" | "invalid-checked" | "invalid-unchecked";
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const Checkbox: React.FC<CheckboxProps>;
export default Checkbox;
