import { LucideCheck } from './LucideCheck.jsx';

// figma node: 40:3612 Checkbox (8 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "interaction=" + __venc(p.interaction) + '|' + "dataState=" + __venc(p.dataState);

export function Checkbox(_p = {}) {
  const props = { ..._p, interaction: _p.interaction ?? "default", dataState: _p.dataState ?? "checked" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--background-surface)",
      borderTop: "1px solid var(--border-color-strong)",
      borderRight: "1px solid var(--border-color-strong)",
      borderBottom: "1px solid var(--border-color-strong)",
      borderLeft: "1px solid var(--border-color-strong)",
      position: "relative",
      ...props.style,
    }} />
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--background-surface)",
      borderTop: "1px solid var(--border-color-strong)",
      borderRight: "1px solid var(--border-color-strong)",
      borderBottom: "1px solid var(--border-color-strong)",
      borderLeft: "1px solid var(--border-color-strong)",
      boxShadow: "0px 0px 0px 3px rgb(215,215,215)",
      position: "relative",
      ...props.style,
    }} />
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      opacity: 0.5,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--background-muted)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      position: "relative",
      ...props.style,
    }} />
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--text-brand)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "absolute",
          left: 1,
          top: 1,
          width: 14,
          height: 14,
        }}>{props.icon1 ?? <LucideCheck style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--text-brand)",
      borderTop: "1px solid var(--border-color-strong)",
      borderRight: "1px solid var(--border-color-strong)",
      borderBottom: "1px solid var(--border-color-strong)",
      borderLeft: "1px solid var(--border-color-strong)",
      boxShadow: "0px 0px 0px 3px rgb(215,215,215)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "absolute",
          left: 1,
          top: 1,
          width: 14,
          height: 14,
        }}>{props.icon1 ?? <LucideCheck style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      opacity: 0.5,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--text-disabled)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "absolute",
          left: 1,
          top: 1,
          width: 14,
          height: 14,
        }}>{props.icon1 ?? <LucideCheck style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __body6 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--background-surface)",
      borderTop: "1px solid var(--color-red-400)",
      borderRight: "1px solid var(--color-red-400)",
      borderBottom: "1px solid var(--color-red-400)",
      borderLeft: "1px solid var(--color-red-400)",
      boxShadow: "0px 0px 0px 3px rgba(199,70,70,0.2)",
      position: "relative",
      ...props.style,
    }} />
  );
  const __body7 = () => (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "var(--text-brand)",
      boxShadow: "0px 0px 0px 3px rgba(199,70,70,0.2)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "absolute",
          left: 1,
          top: 1,
          width: 14,
          height: 14,
        }}>{props.icon1 ?? <LucideCheck style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
  const __impls = {
    // figma: Interaction=Default, Data state=Unchecked
    "interaction=default|dataState=unchecked": __body0,
    // figma: Interaction=Focus, Data state=Unchecked
    "interaction=focus|dataState=unchecked": __body1,
    // figma: Interaction=Disabled, Data state=Unchecked
    "interaction=disabled|dataState=unchecked": __body2,
    // figma: Interaction=Default, Data state=Checked
    "interaction=default|dataState=checked": __body3,
    // figma: Interaction=Focus, Data state=Checked
    "interaction=focus|dataState=checked": __body4,
    // figma: Interaction=Disabled, Data state=Checked
    "interaction=disabled|dataState=checked": __body5,
    // figma: Interaction=Invalid, Data state=Invalid-unchecked
    "interaction=invalid|dataState=invalid-unchecked": __body6,
    // figma: Interaction=Invalid, Data state=Invalid-checked
    "interaction=invalid|dataState=invalid-checked": __body7,
  };
  return (__impls[__vkey(props)] ?? __body3)();
}
export default Checkbox;
