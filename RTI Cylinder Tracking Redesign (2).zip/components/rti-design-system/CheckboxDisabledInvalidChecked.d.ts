import * as React from 'react';
export interface CheckboxDisabledInvalidCheckedProps {
  className?: string;
  style?: React.CSSProperties;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const CheckboxDisabledInvalidChecked: React.FC<CheckboxDisabledInvalidCheckedProps>;
export default CheckboxDisabledInvalidChecked;
