import { LucideCheck } from './LucideCheck.jsx';

// figma node: 40:3625 Checkbox/Disabled/Invalid-checked
export function CheckboxDisabledInvalidChecked(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 16,
      height: 16,
      overflow: "hidden",
      borderRadius: 4,
      backgroundColor: "rgba(231,0,11,0.1)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
          position: "absolute",
          left: 1,
          top: 1,
          width: 14,
          height: 14,
        }}>{props.icon1 ?? <LucideCheck style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
    </div>
  );
}
export default CheckboxDisabledInvalidChecked;
