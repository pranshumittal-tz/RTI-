// figma node: 32:1492 Chevron Down
export function ChevronDown(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={12.917} height={7.083} viewBox="0 0 12.917 7.083" fill="none" style={{
        position: "absolute",
        left: 3.542,
        top: 6.875,
        width: 12.917,
        height: 7.083,
      }}>
        <path d={"M 0.183 0.183 C 0.427 -0.061 0.823 -0.061 1.067 0.183 L 6.458 5.574 L 11.85 0.183 C 12.094 -0.061 12.489 -0.061 12.734 0.183 C 12.978 0.427 12.978 0.823 12.734 1.067 L 6.9 6.9 C 6.783 7.017 6.624 7.083 6.458 7.083 C 6.293 7.083 6.134 7.017 6.016 6.9 L 0.183 1.067 C -0.061 0.823 -0.061 0.427 0.183 0.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
}
export default ChevronDown;
