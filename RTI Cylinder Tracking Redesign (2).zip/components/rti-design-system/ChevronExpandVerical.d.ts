import * as React from 'react';
export interface ChevronExpandVericalProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const ChevronExpandVerical: React.FC<ChevronExpandVericalProps>;
export default ChevronExpandVerical;
