// figma node: 46:4018 chevron expand verical
export function ChevronExpandVerical(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={7.917} height={4.583} viewBox="0 0 7.917 4.583" fill="none" style={{
        position: "absolute",
        left: 6.042,
        top: 11.875,
        width: 7.917,
        height: 4.583,
      }}>
        <path d={"M 0.183 0.183 C 0.427 -0.061 0.823 -0.061 1.067 0.183 L 3.958 3.074 L 6.85 0.183 C 7.094 -0.061 7.489 -0.061 7.734 0.183 C 7.978 0.427 7.978 0.823 7.734 1.067 L 4.4 4.4 C 4.156 4.644 3.76 4.644 3.516 4.4 L 0.183 1.067 C -0.061 0.823 -0.061 0.427 0.183 0.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.917} height={4.583} viewBox="0 0 7.917 4.583" fill="none" style={{
        position: "absolute",
        left: 6.042,
        top: 3.542,
        width: 7.917,
        height: 4.583,
      }}>
        <path d={"M 3.516 0.183 C 3.76 -0.061 4.156 -0.061 4.4 0.183 L 7.734 3.516 C 7.978 3.76 7.978 4.156 7.734 4.4 C 7.489 4.644 7.094 4.644 6.85 4.4 L 3.958 1.509 L 1.067 4.4 C 0.823 4.644 0.427 4.644 0.183 4.4 C -0.061 4.156 -0.061 3.76 0.183 3.516 L 3.516 0.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
}
export default ChevronExpandVerical;
