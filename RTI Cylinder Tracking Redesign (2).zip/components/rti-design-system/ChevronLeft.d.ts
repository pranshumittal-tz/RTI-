import * as React from 'react';
export interface ChevronLeftProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const ChevronLeft: React.FC<ChevronLeftProps>;
export default ChevronLeft;
