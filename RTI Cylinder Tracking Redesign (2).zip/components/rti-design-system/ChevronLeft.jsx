// figma node: 49:5368 Chevron Left
export function ChevronLeft(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={5.833} height={11.667} viewBox="0 0 5.833 11.667" fill="none" style={{
        position: "absolute",
        left: 6.667,
        top: 4.167,
        width: 5.833,
        height: 11.667,
      }}>
        <path d={"M 5.303 12.197 C 5.596 12.49 6.071 12.49 6.364 12.197 C 6.657 11.904 6.657 11.429 6.364 11.136 L 5.833 11.667 L 5.303 12.197 Z M 0 5.833 L -0.53 5.303 C -0.823 5.596 -0.823 6.071 -0.53 6.364 L 0 5.833 Z M 6.364 0.53 C 6.657 0.237 6.657 -0.237 6.364 -0.53 C 6.071 -0.823 5.596 -0.823 5.303 -0.53 L 5.833 0 L 6.364 0.53 Z M 5.833 11.667 L 6.364 11.136 L 0.53 5.303 L 0 5.833 L -0.53 6.364 L 5.303 12.197 L 5.833 11.667 Z M 0 5.833 L 0.53 6.364 L 6.364 0.53 L 5.833 0 L 5.303 -0.53 L -0.53 5.303 L 0 5.833 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
}
export default ChevronLeft;
