// figma node: 32:1486 Chevron Right
export function ChevronRight(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={7.083} height={12.917} viewBox="0 0 7.083 12.917" fill="none" style={{
        position: "absolute",
        left: 6.875,
        top: 3.542,
        width: 7.083,
        height: 12.917,
      }}>
        <path d={"M 0.183 0.183 C 0.427 -0.061 0.823 -0.061 1.067 0.183 L 6.9 6.016 C 7.144 6.26 7.144 6.656 6.9 6.9 L 1.067 12.734 C 0.823 12.978 0.427 12.978 0.183 12.734 C -0.061 12.489 -0.061 12.094 0.183 11.85 L 5.574 6.458 L 0.183 1.067 C -0.061 0.823 -0.061 0.427 0.183 0.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
}
export default ChevronRight;
