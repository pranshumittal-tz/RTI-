// figma node: 67:8661 Chevron Up
export function ChevronUp(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={11.667} height={5.833} viewBox="0 0 11.667 5.833" fill="none" style={{
        position: "absolute",
        left: 4.167,
        top: 7.5,
        width: 11.667,
        height: 5.833,
      }}>
        <path d={"M -0.53 5.303 C -0.823 5.596 -0.823 6.071 -0.53 6.364 C -0.237 6.657 0.237 6.657 0.53 6.364 L 0 5.833 L -0.53 5.303 Z M 5.833 0 L 6.364 -0.53 C 6.071 -0.823 5.596 -0.823 5.303 -0.53 L 5.833 0 Z M 11.136 6.364 C 11.429 6.657 11.904 6.657 12.197 6.364 C 12.49 6.071 12.49 5.596 12.197 5.303 L 11.667 5.833 L 11.136 6.364 Z M 0 5.833 L 0.53 6.364 L 6.364 0.53 L 5.833 0 L 5.303 -0.53 L -0.53 5.303 L 0 5.833 Z M 5.833 0 L 5.303 0.53 L 11.136 6.364 L 11.667 5.833 L 12.197 5.303 L 6.364 -0.53 L 5.833 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
}
export default ChevronUp;
