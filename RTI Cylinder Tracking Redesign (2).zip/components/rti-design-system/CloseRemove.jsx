// figma node: 79:9397 Close remove
export function CloseRemove(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={10} height={10} viewBox="0 0 10 10" fill="none" style={{
        position: "absolute",
        left: 5,
        top: 5,
        width: 10,
        height: 10,
      }}>
        <path d={"M 0.53 -0.53 C 0.237 -0.823 -0.237 -0.823 -0.53 -0.53 C -0.823 -0.237 -0.823 0.237 -0.53 0.53 L 0 0 L 0.53 -0.53 Z M 9.47 10.53 C 9.763 10.823 10.237 10.823 10.53 10.53 C 10.823 10.237 10.823 9.763 10.53 9.47 L 10 10 L 9.47 10.53 Z M 0 0 L -0.53 0.53 L 9.47 10.53 L 10 10 L 10.53 9.47 L 0.53 -0.53 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={10} height={10} viewBox="0 0 10 10" fill="none" style={{
        position: "absolute",
        left: 5,
        top: 5,
        width: 10,
        height: 10,
      }}>
        <path d={"M 10.53 0.53 C 10.823 0.237 10.823 -0.237 10.53 -0.53 C 10.237 -0.823 9.763 -0.823 9.47 -0.53 L 10 0 L 10.53 0.53 Z M -0.53 9.47 C -0.823 9.763 -0.823 10.237 -0.53 10.53 C -0.237 10.823 0.237 10.823 0.53 10.53 L 0 10 L -0.53 9.47 Z M 10 0 L 9.47 -0.53 L -0.53 9.47 L 0 10 L 0.53 10.53 L 10.53 0.53 L 10 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
}
export default CloseRemove;
