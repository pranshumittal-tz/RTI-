import * as React from 'react';
export interface Component1Props {
  className?: string;
  style?: React.CSSProperties;
  variant?: "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "11" | "12" | "13" | "14" | "15" | "16" | "17" | "18" | "19" | "20" | "21" | "22" | "23" | "24";
}
export declare const Component1: React.FC<Component1Props>;
export default Component1;
