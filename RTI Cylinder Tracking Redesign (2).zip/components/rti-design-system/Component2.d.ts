import * as React from 'react';
export interface Component2Props {
  className?: string;
  style?: React.CSSProperties;
  text?: string;
  variant?: "1";
  hover?: boolean;
  /** Text content; defaults to "Dashboard". */
  text1?: string;
}
export declare const Component2: React.FC<Component2Props>;
export default Component2;
