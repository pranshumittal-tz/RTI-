import * as React from 'react';
export interface ConsolidationProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Consolidation: React.FC<ConsolidationProps>;
export default Consolidation;
