import * as React from 'react';
export interface DASHBOARDProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const DASHBOARD: React.FC<DASHBOARDProps>;
export default DASHBOARD;
