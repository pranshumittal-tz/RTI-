import * as React from 'react';
export interface DeleteProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Delete: React.FC<DeleteProps>;
export default Delete;
