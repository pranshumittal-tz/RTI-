// figma node: 4:58 Delete
export function Delete(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={15.333} height={12.952} viewBox="0 0 15.333 12.952" fill="none" style={{
        position: "absolute",
        left: 4.334,
        top: 8.797,
        width: 15.333,
        height: 12.952,
      }}>
        <path d={"M 0.695 0.002 C 1.108 -0.028 1.468 0.282 1.498 0.695 L 2.11 9.071 C 2.208 10.413 3.325 11.452 4.67 11.452 L 10.663 11.452 C 12.008 11.452 13.125 10.413 13.223 9.072 L 13.835 0.695 C 13.865 0.282 14.224 -0.028 14.637 0.002 C 15.05 0.032 15.361 0.392 15.331 0.805 L 14.719 9.181 C 14.564 11.306 12.795 12.952 10.663 12.952 L 4.67 12.952 C 2.539 12.952 0.769 11.306 0.614 9.18 L 0.002 0.805 C -0.028 0.392 0.282 0.032 0.695 0.002 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={18.030} height={1.500} viewBox="0 0 18.030 1.500" fill="none" style={{
        position: "absolute",
        left: 2.985,
        top: 5.652,
        width: 18.03,
        height: 1.5,
      }}>
        <path d={"M 0 0.75 C 0 0.336 0.336 0 0.75 0 L 17.28 0 C 17.694 0 18.03 0.336 18.03 0.75 C 18.03 1.164 17.694 1.5 17.28 1.5 L 0.75 1.5 C 0.336 1.5 0 1.164 0 0.75 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={9.039} height={4.901} viewBox="0 0 9.039 4.901" fill="none" style={{
        position: "absolute",
        left: 7.482,
        top: 2.25,
        width: 9.039,
        height: 4.901,
      }}>
        <path d={"M 2.461 0 L 6.581 0 C 7.484 0 8.277 0.607 8.511 1.481 C 8.515 1.496 8.518 1.511 8.521 1.526 L 9.024 4.002 C 9.107 4.408 8.844 4.804 8.438 4.886 C 8.032 4.969 7.637 4.706 7.554 4.301 L 7.057 1.852 C 6.993 1.644 6.8 1.5 6.581 1.5 L 2.457 1.5 C 2.236 1.499 2.042 1.643 1.978 1.852 L 1.485 4.299 C 1.404 4.705 1.008 4.968 0.602 4.887 C 0.196 4.805 -0.067 4.409 0.015 4.003 L 0.513 1.527 C 0.516 1.512 0.52 1.496 0.524 1.481 C 0.759 0.604 1.554 -0.002 2.461 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={4.880} height={6.008} viewBox="0 0 4.880 6.008" fill="none" style={{
        position: "absolute",
        left: 9.352,
        top: 11.031,
        width: 4.88,
        height: 6.008,
      }}>
        <path d={"M 0.75 0 C 1.164 0 1.5 0.336 1.5 0.75 L 1.5 5.258 C 1.5 5.673 1.164 6.008 0.75 6.008 C 0.336 6.008 0 5.673 0 5.258 L 0 0.75 C 0 0.336 0.336 0 0.75 0 Z M 4.13 0 C 4.545 0 4.88 0.336 4.88 0.75 L 4.88 5.258 C 4.88 5.673 4.545 6.008 4.13 6.008 C 3.716 6.008 3.38 5.673 3.38 5.258 L 3.38 0.75 C 3.38 0.336 3.716 0 4.13 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
}
export default Delete;
