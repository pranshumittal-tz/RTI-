import * as React from 'react';
export interface EmptyStateProps {
  className?: string;
  style?: React.CSSProperties;
  /** Text content; defaults to "Place your Title here". */
  text1?: string;
  /** Text content; defaults to "Fill text box with content". */
  text2?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const EmptyState: React.FC<EmptyStateProps>;
export default EmptyState;
