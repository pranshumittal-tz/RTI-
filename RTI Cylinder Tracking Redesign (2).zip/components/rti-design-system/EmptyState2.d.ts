import * as React from 'react';
export interface EmptyState2Props {
  className?: string;
  style?: React.CSSProperties;
}
export declare const EmptyState2: React.FC<EmptyState2Props>;
export default EmptyState2;
