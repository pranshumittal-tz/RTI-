import { Component1 } from './Component1.jsx';
import { Consolidation } from './Consolidation.jsx';
import { Customers } from './Customers.jsx';
import { DASHBOARD } from './DASHBOARD.jsx';
import { Scan } from './Scan.jsx';
import { SidebarPanel } from './SidebarPanel.jsx';

// figma node: 133:9148 Empty State
export function EmptyState2(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 801,
      backgroundColor: "var(--color-neutral-0)",
      display: "flex",
      flexDirection: "column",
      gap: 27,
      padding: "24px 24px 24px 24px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      color: "var(--color-brand-500)",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 566,
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 24,
          lineHeight: "32px",
          color: "var(--color-neutral-800)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>Sidebar</span>
        <span style={{
          position: "relative",
          fontFamily: "\"DM Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 24,
          lineHeight: "32px",
          color: "var(--color-neutral-600)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>Sidebar navigations help the user navigate through an application. </span>
      </div>
      <div style={{
        position: "relative",
        width: 411.22,
        height: 864.346,
        overflow: "hidden",
        borderRadius: 5,
        backgroundColor: "var(--color-neutral-25)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "absolute",
          left: 20,
          top: 20.706,
          width: 232.9,
          height: 823.64,
          backgroundColor: "var(--background-surface)",
          borderRight: "1px solid var(--border-color-subtle)",
          display: "flex",
          flexDirection: "column",
          padding: "0px 0.909px 0px 0px",
          alignItems: "flex-start",
          flexWrap: "nowrap",
          boxSizing: "border-box",
        }}>
          <div style={{
            position: "relative",
            height: 64,
            borderBottom: "1px solid var(--border-color-subtle)",
            display: "flex",
            flexDirection: "row",
            padding: "16px 20px 16px 20px",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              gap: 8,
              alignItems: "center",
              flexWrap: "nowrap",
              flexShrink: 0,
            }}>
              <div style={{
                position: "relative",
                width: 25.99,
                height: 25.99,
                borderRadius: 8,
                backgroundColor: "var(--color-grey-7)",
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "nowrap",
                flexShrink: 0,
              }}>
                <Component1
                  style={{
                    position: "relative",
                    width: 14,
                    height: 14,
                    flexShrink: 0,
                  }}
                  variant={"1"}
                />
              </div>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                padding: "0.450px 0px 0.910px 0px",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                boxSizing: "border-box",
                flexShrink: 0,
              }}>
                <span style={{
                  position: "relative",
                  fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                  fontWeight: 700,
                  fontSize: 15,
                  whiteSpace: "nowrap",
                  lineHeight: "100%",
                  letterSpacing: "-0.150px",
                  color: "var(--color-grey-7)",
                  flexShrink: 0,
                }}>RTI</span>
              </div>
            </div>
            <div style={{
                position: "relative",
                width: 16,
                height: 16,
                flexShrink: 0,
              }}>
              <SidebarPanel style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
            </div>
          </div>
          <div style={{
            position: "relative",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            padding: "16px 12px 16px 12px",
            justifyContent: "space-between",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexGrow: 1,
            alignSelf: "stretch",
          }}>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "column",
              gap: 16,
              alignItems: "flex-start",
              flexWrap: "nowrap",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                gap: 8,
                alignItems: "flex-start",
                flexWrap: "nowrap",
                flexShrink: 0,
                alignSelf: "stretch",
              }}>
                <div style={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  padding: "0px 8px 0px 8px",
                  alignItems: "flex-start",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <span style={{
                    position: "relative",
                    fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 12,
                    lineHeight: "16px",
                    color: "var(--text-secondary)",
                    flexShrink: 0,
                    alignSelf: "stretch",
                  }}>MAIN</span>
                </div>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "row",
                  gap: 10,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <DASHBOARD style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                  <span style={{
                    position: "relative",
                    fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 13,
                    whiteSpace: "nowrap",
                    lineHeight: "18px",
                    color: "var(--text-secondary)",
                    flexShrink: 0,
                  }}>Dashboard</span>
                </div>
              </div>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                gap: 8,
                alignItems: "flex-start",
                flexWrap: "nowrap",
                flexShrink: 0,
                alignSelf: "stretch",
              }}>
                <div style={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  padding: "0px 8px 0px 8px",
                  alignItems: "flex-start",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <span style={{
                    position: "relative",
                    fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 12,
                    lineHeight: "16px",
                    color: "var(--text-secondary)",
                    flexShrink: 0,
                    alignSelf: "stretch",
                  }}>OPERATIONS</span>
                </div>
                <div style={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                  alignItems: "flex-start",
                  flexWrap: "nowrap",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <div style={{
                    position: "relative",
                    borderRadius: 8,
                    display: "flex",
                    flexDirection: "row",
                    gap: 8,
                    padding: "8px 8px 8px 8px",
                    alignItems: "center",
                    flexWrap: "nowrap",
                    boxSizing: "border-box",
                    flexShrink: 0,
                    alignSelf: "stretch",
                  }}>
                    <div style={{
                        position: "relative",
                        width: 16,
                        height: 16,
                        flexShrink: 0,
                      }}>
                      <Customers style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                    </div>
                    <span style={{
                      position: "relative",
                      fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                      fontWeight: 500,
                      fontSize: 13,
                      whiteSpace: "nowrap",
                      lineHeight: "18px",
                      color: "var(--text-primary)",
                      flexShrink: 0,
                    }}>Customers</span>
                  </div>
                  <div style={{
                    position: "relative",
                    borderRadius: 8,
                    display: "flex",
                    flexDirection: "row",
                    gap: 8,
                    padding: "8px 8px 8px 8px",
                    alignItems: "center",
                    flexWrap: "nowrap",
                    boxSizing: "border-box",
                    flexShrink: 0,
                    alignSelf: "stretch",
                  }}>
                    <div style={{
                        position: "relative",
                        width: 16,
                        height: 16,
                        flexShrink: 0,
                      }}>
                      <Consolidation style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                    </div>
                    <span style={{
                      position: "relative",
                      fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                      fontWeight: 500,
                      fontSize: 13,
                      whiteSpace: "nowrap",
                      lineHeight: "18px",
                      color: "var(--text-primary)",
                      flexShrink: 0,
                    }}>Consolidation</span>
                  </div>
                  <div style={{
                    position: "relative",
                    borderRadius: 8,
                    display: "flex",
                    flexDirection: "row",
                    gap: 8,
                    padding: "8px 8px 8px 8px",
                    alignItems: "center",
                    flexWrap: "nowrap",
                    boxSizing: "border-box",
                    flexShrink: 0,
                    alignSelf: "stretch",
                  }}>
                    <div style={{
                        position: "relative",
                        width: 16,
                        height: 16,
                        flexShrink: 0,
                      }}>
                      <Scan style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                    </div>
                    <span style={{
                      position: "relative",
                      fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                      fontWeight: 500,
                      fontSize: 13,
                      whiteSpace: "nowrap",
                      lineHeight: "18px",
                      color: "var(--text-primary)",
                      flexShrink: 0,
                    }}>Barcoding</span>
                  </div>
                </div>
              </div>
            </div>
            <div style={{
              position: "relative",
              borderRadius: 8,
              backgroundColor: "var(--color-brand-25)",
              display: "flex",
              flexDirection: "row",
              gap: 4,
              padding: "8px 8px 8px 8px",
              alignItems: "center",
              flexWrap: "nowrap",
              boxSizing: "border-box",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>
              <div style={{
                position: "relative",
                width: 28,
                height: 28,
                overflow: "hidden",
                flexShrink: 0,
              }}>
                <div style={{
                  position: "absolute",
                  left: 0,
                  top: 0,
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  backgroundColor: "var(--color-brand-100)",
                }} />
                <div style={{
                  position: "absolute",
                  left: 6,
                  top: 7,
                  width: 16,
                  height: 16,
                  overflow: "hidden",
                }}>
                  <div style={{
                    position: "absolute",
                    left: 1.5,
                    top: 1.5,
                    width: 12.814,
                    height: 13.002,
                    overflow: "hidden",
                  }}>
                    <svg width={12.814} height={13.002} viewBox="0 0 12.814 13.002" fill="none" style={{
                      position: "absolute",
                      left: 0,
                      top: 0,
                      width: 12.814,
                      height: 13.002,
                    }}>
                      <path d={"M 12.567 0.447 C 12.457 0.308 12.317 0.196 12.158 0.118 C 11.998 0.041 11.824 0.001 11.647 0 L 2.5 0 C 1.837 0 1.201 0.263 0.732 0.732 C 0.263 1.201 0 1.837 0 2.5 L 0 3.833 C 0.001 4.392 0.189 4.934 0.535 5.373 C 0.881 5.812 1.364 6.122 1.907 6.253 L 1.067 10.447 C 0.955 11.002 1.069 11.579 1.383 12.05 C 1.697 12.521 2.185 12.849 2.74 12.96 C 3.295 13.071 3.872 12.958 4.343 12.644 C 4.815 12.33 5.142 11.842 5.253 11.287 L 5.713 9 L 7.167 9 C 7.278 8.999 7.387 8.961 7.475 8.893 C 7.563 8.824 7.625 8.728 7.653 8.62 L 8.227 6.333 L 10.647 6.333 C 10.908 6.334 11.161 6.246 11.366 6.086 C 11.572 5.925 11.717 5.7 11.78 5.447 L 12.78 1.447 C 12.822 1.275 12.825 1.095 12.788 0.922 C 12.751 0.749 12.675 0.586 12.567 0.447 Z M 1 3.833 L 1 2.5 C 1 2.102 1.158 1.721 1.439 1.439 C 1.721 1.158 2.102 1 2.5 1 L 9.833 1 L 8.747 5.333 L 2.5 5.333 C 2.102 5.333 1.721 5.175 1.439 4.894 C 1.158 4.613 1 4.231 1 3.833 Z M 4.273 11.087 C 4.221 11.343 4.083 11.573 3.882 11.739 C 3.68 11.906 3.428 11.998 3.167 12 C 3.001 12 2.838 11.963 2.688 11.893 C 2.538 11.822 2.405 11.72 2.299 11.593 C 2.193 11.466 2.116 11.317 2.073 11.157 C 2.031 10.997 2.024 10.83 2.053 10.667 L 2.913 6.36 L 5.233 6.36 L 4.273 11.087 Z M 6.773 8 L 5.907 8 L 6.24 6.333 L 7.167 6.333 L 6.773 8 Z M 10.807 5.207 C 10.797 5.242 10.776 5.273 10.747 5.296 C 10.719 5.319 10.683 5.332 10.647 5.333 L 9.833 5.333 L 10.92 1 L 11.673 1 C 11.699 0.999 11.725 1.005 11.748 1.017 C 11.771 1.028 11.792 1.046 11.807 1.067 C 11.817 1.089 11.822 1.112 11.822 1.137 C 11.822 1.161 11.817 1.185 11.807 1.207 L 10.807 5.207 Z"} fill="currentColor" fillRule="nonzero" />
                    </svg>
                  </div>
                </div>
              </div>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                flexGrow: 1,
              }}>
                <span style={{
                  position: "relative",
                  fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                  fontWeight: 500,
                  fontSize: 12,
                  whiteSpace: "nowrap",
                  lineHeight: "16px",
                  color: "var(--text-secondary)",
                  flexShrink: 0,
                }}>RTI-HH020</span>
                <div style={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "row",
                  gap: 4,
                  alignItems: "center",
                  flexWrap: "nowrap",
                  flexShrink: 0,
                }}>
                  <div style={{
                    position: "relative",
                    width: 4,
                    height: 4,
                    borderRadius: "50%",
                    backgroundColor: "var(--color-green-200)",
                    flexShrink: 0,
                  }} />
                  <span style={{
                    position: "relative",
                    fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 12,
                    whiteSpace: "nowrap",
                    lineHeight: "16px",
                    color: "var(--color-green-200)",
                    flexShrink: 0,
                  }}>Connected</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div style={{
          position: "absolute",
          left: 327.22,
          top: 20,
          height: 823.64,
          backgroundColor: "var(--background-surface)",
          borderRight: "1px solid var(--border-color-subtle)",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          flexWrap: "nowrap",
        }}>
          <div style={{
            position: "relative",
            borderBottom: "1px solid var(--border-color-subtle)",
            display: "flex",
            flexDirection: "column",
            gap: 8,
            padding: "16px 20px 16px 20px",
            justifyContent: "center",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexShrink: 0,
          }}>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "column",
              gap: 16,
              justifyContent: "center",
              alignItems: "center",
              flexWrap: "nowrap",
              flexShrink: 0,
            }}>
              <div style={{
                position: "relative",
                width: 24,
                height: 24,
                display: "flex",
                flexDirection: "row",
                gap: 8,
                alignItems: "center",
                flexWrap: "nowrap",
                flexShrink: 0,
              }}>
                <div style={{
                  position: "relative",
                  width: 24,
                  borderRadius: 8,
                  backgroundColor: "var(--color-grey-7)",
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <Component1
                    style={{
                      position: "relative",
                      width: 14,
                      height: 14,
                      flexShrink: 0,
                    }}
                    variant={"1"}
                  />
                </div>
              </div>
              <div style={{
                  position: "relative",
                  width: 16,
                  height: 16,
                  flexShrink: 0,
                }}>
                <SidebarPanel style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
              </div>
            </div>
          </div>
          <div style={{
            position: "relative",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            padding: "16px 12px 16px 12px",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexGrow: 1,
            alignSelf: "stretch",
          }}>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "column",
              gap: 16,
              alignItems: "flex-start",
              flexWrap: "nowrap",
              flexShrink: 0,
            }}>
              <div style={{
                position: "relative",
                borderRadius: 8,
                display: "flex",
                flexDirection: "row",
                gap: 10,
                padding: "8px 8px 8px 8px",
                alignItems: "center",
                flexWrap: "nowrap",
                boxSizing: "border-box",
                flexShrink: 0,
              }}>
                <div style={{
                    position: "relative",
                    width: 16,
                    height: 16,
                    flexShrink: 0,
                  }}>
                  <DASHBOARD style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                </div>
              </div>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                gap: 8,
                alignItems: "flex-start",
                flexWrap: "nowrap",
                flexShrink: 0,
              }}>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "row",
                  gap: 8,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <Customers style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                </div>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "row",
                  gap: 8,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <Consolidation style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                </div>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "row",
                  gap: 8,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <Scan style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                </div>
              </div>
            </div>
            <div style={{
              position: "relative",
              width: 28,
              height: 28,
              overflow: "hidden",
              flexShrink: 0,
            }}>
              <div style={{
                position: "absolute",
                left: 0,
                top: 0,
                width: 28,
                height: 28,
                borderRadius: "50%",
                backgroundColor: "var(--color-brand-100)",
              }} />
              <div style={{
                position: "absolute",
                left: 6,
                top: 7,
                width: 16,
                height: 16,
                overflow: "hidden",
              }}>
                <div style={{
                  position: "absolute",
                  left: 1.5,
                  top: 1.5,
                  width: 12.814,
                  height: 13.002,
                  overflow: "hidden",
                }}>
                  <svg width={12.814} height={13.002} viewBox="0 0 12.814 13.002" fill="none" style={{
                    position: "absolute",
                    left: 0,
                    top: 0,
                    width: 12.814,
                    height: 13.002,
                  }}>
                    <path d={"M 12.567 0.447 C 12.457 0.308 12.317 0.196 12.158 0.118 C 11.998 0.041 11.824 0.001 11.647 0 L 2.5 0 C 1.837 0 1.201 0.263 0.732 0.732 C 0.263 1.201 0 1.837 0 2.5 L 0 3.833 C 0.001 4.392 0.189 4.934 0.535 5.373 C 0.881 5.812 1.364 6.122 1.907 6.253 L 1.067 10.447 C 0.955 11.002 1.069 11.579 1.383 12.05 C 1.697 12.521 2.185 12.849 2.74 12.96 C 3.295 13.071 3.872 12.958 4.343 12.644 C 4.815 12.33 5.142 11.842 5.253 11.287 L 5.713 9 L 7.167 9 C 7.278 8.999 7.387 8.961 7.475 8.893 C 7.563 8.824 7.625 8.728 7.653 8.62 L 8.227 6.333 L 10.647 6.333 C 10.908 6.334 11.161 6.246 11.366 6.086 C 11.572 5.925 11.717 5.7 11.78 5.447 L 12.78 1.447 C 12.822 1.275 12.825 1.095 12.788 0.922 C 12.751 0.749 12.675 0.586 12.567 0.447 Z M 1 3.833 L 1 2.5 C 1 2.102 1.158 1.721 1.439 1.439 C 1.721 1.158 2.102 1 2.5 1 L 9.833 1 L 8.747 5.333 L 2.5 5.333 C 2.102 5.333 1.721 5.175 1.439 4.894 C 1.158 4.613 1 4.231 1 3.833 Z M 4.273 11.087 C 4.221 11.343 4.083 11.573 3.882 11.739 C 3.68 11.906 3.428 11.998 3.167 12 C 3.001 12 2.838 11.963 2.688 11.893 C 2.538 11.822 2.405 11.72 2.299 11.593 C 2.193 11.466 2.116 11.317 2.073 11.157 C 2.031 10.997 2.024 10.83 2.053 10.667 L 2.913 6.36 L 5.233 6.36 L 4.273 11.087 Z M 6.773 8 L 5.907 8 L 6.24 6.333 L 7.167 6.333 L 6.773 8 Z M 10.807 5.207 C 10.797 5.242 10.776 5.273 10.747 5.296 C 10.719 5.319 10.683 5.332 10.647 5.333 L 9.833 5.333 L 10.92 1 L 11.673 1 C 11.699 0.999 11.725 1.005 11.748 1.017 C 11.771 1.028 11.792 1.046 11.807 1.067 C 11.817 1.089 11.822 1.112 11.822 1.137 C 11.822 1.161 11.817 1.185 11.807 1.207 L 10.807 5.207 Z"} fill="currentColor" fillRule="nonzero" />
                  </svg>
                </div>
              </div>
            </div>
            <div style={{
              position: "absolute",
              left: 39,
              top: 694,
              width: 6,
              height: 6,
              borderRadius: "50%",
              backgroundColor: "var(--color-green-200)",
            }} />
          </div>
        </div>
      </div>
    </div>
  );
}
export default EmptyState2;
