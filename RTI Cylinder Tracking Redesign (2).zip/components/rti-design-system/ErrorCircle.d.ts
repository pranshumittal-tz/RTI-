import * as React from 'react';
export interface ErrorCircleProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const ErrorCircle: React.FC<ErrorCircleProps>;
export default ErrorCircle;
