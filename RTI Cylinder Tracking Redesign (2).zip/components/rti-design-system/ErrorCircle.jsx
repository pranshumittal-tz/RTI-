// figma node: 126:8810 Error circle
export function ErrorCircle(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={19} height={19} viewBox="0 0 19 19" fill="none" style={{
        position: "absolute",
        left: 2.5,
        top: 2.5,
        width: 19,
        height: 19,
      }}>
        <path d={"M 9.5 13.969 C 9.086 13.969 8.75 13.657 8.75 13.242 L 8.75 13.195 C 8.75 12.781 9.086 12.445 9.5 12.445 C 9.914 12.445 10.25 12.781 10.25 13.195 C 10.25 13.609 9.914 13.969 9.5 13.969 Z M 8.746 5.808 C 8.746 5.394 9.082 5.058 9.496 5.058 C 9.91 5.058 10.246 5.394 10.246 5.808 L 10.246 10.107 C 10.246 10.521 9.91 10.857 9.496 10.857 C 9.082 10.857 8.746 10.521 8.746 10.107 L 8.746 5.808 Z M 9.5 0 C 4.262 0 0 4.262 0 9.5 C 0 14.739 4.262 19 9.5 19 C 14.738 19 19 14.739 19 9.5 C 19 4.262 14.738 0 9.5 0 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
}
export default ErrorCircle;
