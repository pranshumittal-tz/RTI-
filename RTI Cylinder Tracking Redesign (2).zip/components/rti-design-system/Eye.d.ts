import * as React from 'react';
export interface EyeProps {
  className?: string;
  style?: React.CSSProperties;
  property1?: "hide" | "eye";
}
export declare const Eye: React.FC<EyeProps>;
export default Eye;
