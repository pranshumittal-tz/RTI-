import * as React from 'react';
export interface Eye3Props {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Eye3: React.FC<Eye3Props>;
export default Eye3;
