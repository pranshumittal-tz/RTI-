// figma node: 130:8823 Eye 3
export function Eye3(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={13.333} height={4.160} viewBox="0 0 13.333 4.160" fill="none" style={{
        position: "absolute",
        left: 3.333,
        top: 7.205,
        width: 13.333,
        height: 4.16,
      }}>
        <path d={"M -0.676 3.835 C -0.855 4.209 -0.698 4.657 -0.325 4.836 C 0.048 5.016 0.496 4.859 0.676 4.485 L 0 4.16 L -0.676 3.835 Z M 12.657 4.485 C 12.837 4.859 13.285 5.016 13.658 4.836 C 14.032 4.657 14.189 4.209 14.009 3.835 L 13.333 4.16 L 12.657 4.485 Z M 0 4.16 L 0.676 4.485 C 3.07 -0.495 10.263 -0.495 12.657 4.485 L 13.333 4.16 L 14.009 3.835 C 11.07 -2.278 2.263 -2.278 -0.676 3.835 L 0 4.16 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={3.854} height={3.701} viewBox="0 0 3.854 3.701" fill="none" style={{
        position: "absolute",
        left: 8.076,
        top: 10.648,
        width: 3.854,
        height: 3.701,
      }}>
        <path d={"M 1.927 3.701 L 1.927 2.951 C 1.251 2.951 0.75 2.429 0.75 1.85 L 0 1.85 L -0.75 1.85 C -0.75 3.316 0.482 4.451 1.927 4.451 L 1.927 3.701 Z M 0 1.85 L 0.75 1.85 C 0.75 1.272 1.251 0.75 1.927 0.75 L 1.927 0 L 1.927 -0.75 C 0.482 -0.75 -0.75 0.386 -0.75 1.85 L 0 1.85 Z M 1.927 0 L 1.927 0.75 C 2.603 0.75 3.104 1.272 3.104 1.85 L 3.854 1.85 L 4.604 1.85 C 4.604 0.385 3.372 -0.75 1.927 -0.75 L 1.927 0 Z M 3.854 1.85 L 3.104 1.85 C 3.104 2.429 2.604 2.951 1.927 2.951 L 1.927 3.701 L 1.927 4.451 C 3.371 4.451 4.604 3.317 4.604 1.85 L 3.854 1.85 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
}
export default Eye3;
