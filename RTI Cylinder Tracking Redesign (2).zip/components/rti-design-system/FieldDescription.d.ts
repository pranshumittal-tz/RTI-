import * as React from 'react';
export interface FieldDescriptionProps {
  className?: string;
  style?: React.CSSProperties;
  alignment?: "left" | "right";
  /** Text content; defaults to "Field description". */
  text1?: string;
}
export declare const FieldDescription: React.FC<FieldDescriptionProps>;
export default FieldDescription;
