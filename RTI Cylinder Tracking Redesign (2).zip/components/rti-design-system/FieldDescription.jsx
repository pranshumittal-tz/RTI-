// figma node: 40:1745 FieldDescription (2 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "alignment=" + __venc(p.alignment);

export function FieldDescription(_p = {}) {
  const props = { ..._p, alignment: _p.alignment ?? "left" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 10,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 14,
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--muted-foreground)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Field description"}</span>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 10,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 14,
        textAlign: "right",
        whiteSpace: "nowrap",
        lineHeight: "20px",
        color: "var(--muted-foreground)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.text1 ?? "Field description"}</span>
    </div>
  );
  const __impls = {
    // figma: Alignment=Left
    "alignment=left": __body0,
    // figma: Alignment=Right
    "alignment=right": __body1,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default FieldDescription;
