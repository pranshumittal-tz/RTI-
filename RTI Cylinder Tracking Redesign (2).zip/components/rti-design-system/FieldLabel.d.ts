import * as React from 'react';
export interface FieldLabelProps {
  className?: string;
  style?: React.CSSProperties;
  asterisk?: boolean;
  state?: "default" | "destructive" | "disabled";
  badge?: boolean;
  dir?: "ltr" | "rtl";
  action?: boolean;
  /** Text content; defaults to "Field label". */
  text1?: string;
  /** Text content; defaults to "*". */
  text2?: string;
  /** Text content; defaults to "Action". */
  text3?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const FieldLabel: React.FC<FieldLabelProps>;
export default FieldLabel;
