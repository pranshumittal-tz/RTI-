import * as React from 'react';
export interface ForbiddenSignProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const ForbiddenSign: React.FC<ForbiddenSignProps>;
export default ForbiddenSign;
