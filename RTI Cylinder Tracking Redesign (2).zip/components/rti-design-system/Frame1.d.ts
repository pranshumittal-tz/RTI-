import * as React from 'react';
export interface Frame1Props {
  className?: string;
  style?: React.CSSProperties;
  icon?: boolean;
  property1?: "default" | "active";
  /** Text content; defaults to "Home". */
  text1?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const Frame1: React.FC<Frame1Props>;
export default Frame1;
