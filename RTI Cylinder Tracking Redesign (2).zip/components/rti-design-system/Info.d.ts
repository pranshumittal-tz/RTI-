import * as React from 'react';
export interface InfoProps {
  className?: string;
  style?: React.CSSProperties;
  property1?: "line" | "filled";
}
export declare const Info: React.FC<InfoProps>;
export default Info;
