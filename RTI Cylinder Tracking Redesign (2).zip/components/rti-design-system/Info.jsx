// figma node: 1:34 Info (2 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "property1=" + __venc(p.property1);

export function Info(_p = {}) {
  const props = { ..._p, property1: _p.property1 ?? "line" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--color-greyscale-100)",
      ...props.style,
    }}>
      <svg width={18.720} height={18.720} viewBox="0 0 18.720 18.720" fill="none" style={{
        position: "absolute",
        left: 2.4,
        top: 2.64,
        width: 18.72,
        height: 18.72,
      }}>
        <path d={"M 9.36 1.44 C 4.986 1.44 1.44 4.986 1.44 9.36 C 1.44 13.734 4.986 17.28 9.36 17.28 C 13.734 17.28 17.28 13.734 17.28 9.36 C 17.28 4.986 13.734 1.44 9.36 1.44 Z M 0 9.36 C 0 4.19 4.19 0 9.36 0 C 14.53 0 18.72 4.19 18.72 9.36 C 18.72 14.529 14.53 18.72 9.36 18.72 C 4.19 18.72 0 14.529 0 9.36 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={1.445} height={8.546} viewBox="0 0 1.445 8.546" fill="none" style={{
        position: "absolute",
        left: 11.04,
        top: 7.719,
        width: 1.445,
        height: 8.546,
      }}>
        <path d={"M 0.72 0 C 1.118 0 1.44 0.322 1.44 0.72 L 1.44 0.781 C 1.44 1.178 1.118 1.501 0.72 1.501 C 0.322 1.501 0 1.178 0 0.781 L 0 0.72 C 0 0.322 0.322 0 0.72 0 Z M 0.725 2.978 C 1.123 2.978 1.445 3.301 1.445 3.698 L 1.445 7.826 C 1.445 8.224 1.123 8.546 0.725 8.546 C 0.328 8.546 0.005 8.224 0.005 7.826 L 0.005 3.698 C 0.005 3.301 0.328 2.978 0.725 2.978 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--color-greyscale-100)",
      ...props.style,
    }}>
      <svg width={19} height={19} viewBox="0 0 19 19" fill="none" style={{
        position: "absolute",
        left: 2.5,
        top: 2.5,
        width: 19,
        height: 19,
      }}>
        <path d={"M 10.256 13.193 C 10.256 13.607 9.92 13.943 9.506 13.943 C 9.092 13.943 8.756 13.607 8.756 13.193 L 8.756 8.894 C 8.756 8.48 9.092 8.144 9.506 8.144 C 9.92 8.144 10.256 8.48 10.256 8.894 L 10.256 13.193 Z M 8.75 5.791 C 8.75 5.377 9.086 5.041 9.5 5.041 C 9.914 5.041 10.25 5.377 10.25 5.791 C 10.25 6.205 9.914 6.573 9.5 6.573 C 9.086 6.573 8.75 6.268 8.75 5.854 L 8.75 5.791 Z M 9.5 0 C 4.262 0 0 4.261 0 9.5 C 0 14.738 4.262 19 9.5 19 C 14.738 19 19 14.738 19 9.5 C 19 4.261 14.738 0 9.5 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
  const __impls = {
    // figma: Property 1=Line
    "property1=line": __body0,
    // figma: Property 1=Filled
    "property1=filled": __body1,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Info;
