// figma node: 1:120 info circle
export function InfoCircle(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={18} height={18} viewBox="0 0 18 18" fill="none" style={{
        position: "absolute",
        left: 3,
        top: 3,
        width: 18,
        height: 18,
      }}>
        <path d={"M 0 9 C 0 13.97 4.029 18 9 18 C 13.971 18 18 13.97 18 9 C 18 4.029 13.971 0 9 0 C 4.029 0 0 4.029 0 9 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <div style={{
        position: "absolute",
        left: 12,
        top: 8.291,
        width: 0.006,
        height: 7.402,
        border: "1px dashed currentColor",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
        fontSize: 10,
        opacity: 0.45,
      }}>Vector</div>
    </div>
  );
}
export default InfoCircle;
