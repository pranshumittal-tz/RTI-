import * as React from 'react';
export interface InfoMenuProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const InfoMenu: React.FC<InfoMenuProps>;
export default InfoMenu;
