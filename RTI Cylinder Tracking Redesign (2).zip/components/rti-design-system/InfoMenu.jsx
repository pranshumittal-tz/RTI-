// figma node: 65:8657 Info menu
export function InfoMenu(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={2.917} height={2.917} viewBox="0 0 2.917 2.917" fill="none" style={{
        position: "absolute",
        left: 2.708,
        top: 8.542,
        width: 2.917,
        height: 2.917,
      }}>
        <path d={"M 1.458 1.25 C 1.344 1.25 1.25 1.344 1.25 1.458 C 1.25 1.573 1.344 1.667 1.458 1.667 C 1.573 1.667 1.667 1.573 1.667 1.458 C 1.667 1.344 1.573 1.25 1.458 1.25 Z M 0 1.458 C 0 0.653 0.653 0 1.458 0 C 2.264 0 2.917 0.653 2.917 1.458 C 2.917 2.264 2.264 2.917 1.458 2.917 C 0.653 2.917 0 2.264 0 1.458 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={2.917} height={2.917} viewBox="0 0 2.917 2.917" fill="none" style={{
        position: "absolute",
        left: 8.542,
        top: 8.542,
        width: 2.917,
        height: 2.917,
      }}>
        <path d={"M 1.458 1.25 C 1.344 1.25 1.25 1.344 1.25 1.458 C 1.25 1.573 1.344 1.667 1.458 1.667 C 1.573 1.667 1.667 1.573 1.667 1.458 C 1.667 1.344 1.573 1.25 1.458 1.25 Z M 0 1.458 C 0 0.653 0.653 0 1.458 0 C 2.264 0 2.917 0.653 2.917 1.458 C 2.917 2.264 2.264 2.917 1.458 2.917 C 0.653 2.917 0 2.264 0 1.458 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={2.917} height={2.917} viewBox="0 0 2.917 2.917" fill="none" style={{
        position: "absolute",
        left: 14.375,
        top: 8.542,
        width: 2.917,
        height: 2.917,
      }}>
        <path d={"M 1.458 1.25 C 1.344 1.25 1.25 1.344 1.25 1.458 C 1.25 1.573 1.344 1.667 1.458 1.667 C 1.573 1.667 1.667 1.573 1.667 1.458 C 1.667 1.344 1.573 1.25 1.458 1.25 Z M 0 1.458 C 0 0.653 0.653 0 1.458 0 C 2.264 0 2.917 0.653 2.917 1.458 C 2.917 2.264 2.264 2.917 1.458 2.917 C 0.653 2.917 0 2.264 0 1.458 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
}
export default InfoMenu;
