import * as React from 'react';
export interface InputDropDownProps {
  className?: string;
  style?: React.CSSProperties;
  label?: boolean;
  state?: "default" | "selected" | "filled" | "disabled";
  /** Text content; defaults to "Label". */
  text1?: string;
  /** Text content; defaults to "Enter Barcode". */
  text2?: string;
  /** Text content; defaults to "Value 1". */
  text3?: string;
  /** Text content; defaults to "Value 2". */
  text4?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const InputDropDown: React.FC<InputDropDownProps>;
export default InputDropDown;
