import { Search } from './Search.jsx';

// figma node: 111:7613 Input drop down (4 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "state=" + __venc(p.state);

export function InputDropDown(_p = {}) {
  const props = { ..._p, label: _p.label ?? false, state: _p.state ?? "default" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
        whiteSpace: "nowrap",
      }}>{props.text1 ?? "Label"}</span>
      <div style={{
        position: "relative",
        height: 46,
        borderRadius: 8,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 4px 4px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-placeholder)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text2 ?? "Enter Barcode"}</span>
        <div style={{
          position: "relative",
          borderRadius: 6,
          backgroundColor: "var(--color-neutral-25)",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "8px 8px 8px 8px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon1 ?? <Search style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
        </div>
      </div>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
        whiteSpace: "nowrap",
      }}>{props.text1 ?? "Label"}</span>
      <div style={{
        position: "relative",
        height: 46,
        borderRadius: 8,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 4px 4px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text2 ?? "Value 1"}</span>
        <div style={{
          position: "relative",
          borderRadius: 6,
          backgroundColor: "var(--color-neutral-25)",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "8px 8px 8px 8px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon1 ?? <Search style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
        </div>
      </div>
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
        whiteSpace: "nowrap",
      }}>{props.text1 ?? "Label"}</span>
      <div style={{
        position: "relative",
        height: 46,
        borderRadius: 8,
        backgroundColor: "var(--background-muted)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 4px 4px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text2 ?? "Value 1"}</span>
        <div style={{
          position: "relative",
          borderRadius: 6,
          backgroundColor: "var(--color-neutral-25)",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "8px 8px 8px 8px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon1 ?? <Search style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
        </div>
      </div>
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 500,
        fontSize: 14,
        lineHeight: "20px",
        color: "var(--text-primary)",
        flexShrink: 0,
        alignSelf: "stretch",
        whiteSpace: "nowrap",
      }}>{props.text1 ?? "Label"}</span>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 46,
          borderRadius: 8,
          backgroundColor: "var(--background-surface)",
          boxShadow: "inset 0 0 0 1px var(--border-color-focus)",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "4px 4px 4px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--text-primary)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text2 ?? "|"}</span>
          <div style={{
            position: "relative",
            borderRadius: 6,
            backgroundColor: "var(--color-neutral-25)",
            display: "flex",
            flexDirection: "row",
            gap: 10,
            padding: "8px 8px 8px 8px",
            alignItems: "center",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexShrink: 0,
          }}>
            <div style={{
                position: "relative",
                width: 16,
                height: 16,
                flexShrink: 0,
              }}>{props.icon1 ?? <Search style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
          </div>
        </div>
        <div style={{
          position: "relative",
          borderRadius: 8,
          backgroundColor: "var(--background-surface)",
          boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
          display: "flex",
          flexDirection: "column",
          gap: 8,
          padding: "8px 4px 8px 12px",
          justifyContent: "center",
          alignItems: "flex-start",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Value 1"}</span>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
            whiteSpace: "nowrap",
          }}>{props.text4 ?? "Value 2"}</span>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>Value 3</span>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>Value 4</span>
        </div>
      </div>
    </div>
  );
  const __impls = {
    // figma: State=Default
    "state=default": __body0,
    // figma: State=Filled
    "state=filled": __body1,
    // figma: State=Disabled
    "state=disabled": __body2,
    // figma: State=Selected
    "state=selected": __body3,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default InputDropDown;
