import * as React from 'react';
export interface InputFieldProps {
  className?: string;
  style?: React.CSSProperties;
  label?: boolean;
  icon?: boolean;
  property1?: "default" | "phone" | "focused" | "error" | "filled" | "disabled" | "security";
  leftIcon?: boolean;
  helperText?: boolean;
  helperIcon?: boolean;
  mandatory?: boolean;
  /** Text content; defaults to "Label". */
  text1?: string;
  /** Text content; defaults to "*". */
  text2?: string;
  /** Text content; defaults to "Placeholder". */
  text3?: string;
  /** Text content; defaults to "Helping text". */
  text4?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon3?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon4?: React.ReactNode;
}
export declare const InputField: React.FC<InputFieldProps>;
export default InputField;
