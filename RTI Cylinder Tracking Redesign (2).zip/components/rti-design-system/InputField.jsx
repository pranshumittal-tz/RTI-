import { Arrow } from './Arrow.jsx';
import { Info } from './Info.jsx';
import { InfoCircle } from './InfoCircle.jsx';
import { Lock } from './Lock.jsx';
import { USFlag } from './USFlag.jsx';

// figma node: 1:11 Input field (7 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "property1=" + __venc(p.property1);

export function InputField(_p = {}) {
  const props = { ..._p, label: _p.label ?? true, icon: _p.icon ?? true, property1: _p.property1 ?? "default", leftIcon: _p.leftIcon ?? false, helperText: _p.helperText ?? true, helperIcon: _p.helperIcon ?? false, mandatory: _p.mandatory ?? true };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: 8,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          borderRadius: 12,
          backgroundColor: "var(--form-field-default)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          {props.leftIcon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon2 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--colors-text-text-placeholder)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Placeholder"}</span>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon3 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--form-helpingtext-default)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--colors-text-text-placeholder)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: "calc(var(--spacing-8) * 1px)",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        gap: "calc(var(--spacing-0) * 1px)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "calc(var(--spacing-8) * 1px)",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          borderRadius: 12,
          backgroundColor: "var(--form-field-default)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
          display: "flex",
          flexDirection: "row",
          gap: "calc(var(--spacing-8) * 1px)",
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          paddingLeft: "calc(var(--spacing-12) * 1px)",
          paddingTop: "calc(var(--spacing-12) * 1px)",
          paddingRight: "calc(var(--spacing-12) * 1px)",
          paddingBottom: "calc(var(--spacing-12) * 1px)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon2 ?? <USFlag style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--colors-text-text-placeholder)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "(XXX)-XXX-XXXX"}</span>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon3 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--form-helpingtext-default)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--colors-text-text-placeholder)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: "calc(var(--spacing-8) * 1px)",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        gap: "calc(var(--spacing-0) * 1px)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "calc(var(--spacing-8) * 1px)",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          overflow: "hidden",
          borderRadius: 12,
          backgroundColor: "var(--form-field-default)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-brand), 0px 0px 0px 3px rgba(11,99,54,0.1)",
          display: "flex",
          flexDirection: "row",
          gap: "calc(var(--spacing-8) * 1px)",
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          paddingLeft: "calc(var(--spacing-12) * 1px)",
          paddingTop: "calc(var(--spacing-12) * 1px)",
          paddingRight: "calc(var(--spacing-12) * 1px)",
          paddingBottom: "calc(var(--spacing-12) * 1px)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          {props.leftIcon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon2 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--colors-text-text-heading)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "|"}</span>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon3 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--form-helpingtext-default)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--form-helpingtext-default)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: "calc(var(--spacing-8) * 1px)",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        gap: "calc(var(--spacing-0) * 1px)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "calc(var(--spacing-8) * 1px)",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          borderRadius: 12,
          backgroundColor: "var(--form-field-default)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-error)",
          display: "flex",
          flexDirection: "row",
          gap: "calc(var(--spacing-8) * 1px)",
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          paddingLeft: "calc(var(--spacing-12) * 1px)",
          paddingTop: "calc(var(--spacing-12) * 1px)",
          paddingRight: "calc(var(--spacing-12) * 1px)",
          paddingBottom: "calc(var(--spacing-12) * 1px)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          {props.leftIcon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon2 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--colors-text-text-heading)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Placeholder|"}</span>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon3 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--colors-text-text-error)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--colors-text-text-error)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: "calc(var(--spacing-8) * 1px)",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        gap: "calc(var(--spacing-0) * 1px)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "calc(var(--spacing-8) * 1px)",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          borderRadius: 12,
          backgroundColor: "var(--form-field-default)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
          display: "flex",
          flexDirection: "row",
          gap: "calc(var(--spacing-8) * 1px)",
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          paddingLeft: "calc(var(--spacing-12) * 1px)",
          paddingTop: "calc(var(--spacing-12) * 1px)",
          paddingRight: "calc(var(--spacing-12) * 1px)",
          paddingBottom: "calc(var(--spacing-12) * 1px)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          {props.leftIcon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon2 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--colors-text-text-heading)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Placeholder"}</span>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon3 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--form-helpingtext-default)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--form-helpingtext-default)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: "calc(var(--spacing-8) * 1px)",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        gap: "calc(var(--spacing-0) * 1px)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "calc(var(--spacing-8) * 1px)",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          borderRadius: 12,
          backgroundColor: "var(--colors-bg-bg-disabled)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
          display: "flex",
          flexDirection: "row",
          gap: "calc(var(--spacing-8) * 1px)",
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          paddingLeft: "calc(var(--spacing-12) * 1px)",
          paddingTop: "calc(var(--spacing-12) * 1px)",
          paddingRight: "calc(var(--spacing-12) * 1px)",
          paddingBottom: "calc(var(--spacing-12) * 1px)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          {props.leftIcon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-disabled)",
            }}>{props.icon2 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--colors-text-text-disabled)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Placeholder"}</span>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-disabled)",
            }}>{props.icon3 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--form-helpingtext-default)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--form-helpingtext-default)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __body6 = () => (
    <div className={props.className} style={{
      width: 250,
      display: "flex",
      flexDirection: "column",
      gap: "calc(var(--spacing-8) * 1px)",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      {props.label && (
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        gap: "calc(var(--spacing-0) * 1px)",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-dark)",
            textTransform: "capitalize",
            flexShrink: 0,
          }}>{props.text1 ?? "Label"}</span>
          {props.mandatory && (
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 700,
            fontSize: 14,
            whiteSpace: "nowrap",
            lineHeight: "20px",
            color: "var(--form-label-alert)",
            flexShrink: 0,
          }}>{props.text2 ?? "*"}</span>
          )}
        </div>
        {props.helperIcon && (
        <div style={{
            position: "relative",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}>{props.icon1 ?? <InfoCircle style={{ transform: "scale(0.583, 0.583)", transformOrigin: "0 0" }} />}</div>
        )}
      </div>
      )}
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: "calc(var(--spacing-8) * 1px)",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          height: 48,
          borderRadius: 12,
          backgroundColor: "var(--colors-bg-bg-disabled)",
          boxShadow: "inset 0 0 0 1px var(--colors-border-border-medium)",
          display: "flex",
          flexDirection: "row",
          gap: "calc(var(--spacing-8) * 1px)",
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          paddingLeft: "calc(var(--spacing-12) * 1px)",
          paddingTop: "calc(var(--spacing-12) * 1px)",
          paddingRight: "calc(var(--spacing-12) * 1px)",
          paddingBottom: "calc(var(--spacing-12) * 1px)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          {props.leftIcon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-body-light)",
            }}>{props.icon2 ?? <Arrow arrow={"down"} style={{ transform: "scale(0.667, 0.667)", transformOrigin: "0 0" }} />}</div>
          )}
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 5,
            alignItems: "center",
            flexWrap: "nowrap",
            flexGrow: 1,
          }}>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              gap: 2,
              alignItems: "center",
              flexWrap: "nowrap",
              flexShrink: 0,
            }}>
              <div style={{
                position: "relative",
                width: 3,
                height: 3,
                borderRadius: "50%",
                backgroundColor: "var(--colors-text-text-disabled)",
                flexShrink: 0,
              }} />
              <div style={{
                position: "relative",
                width: 3,
                height: 3,
                borderRadius: "50%",
                backgroundColor: "var(--colors-text-text-disabled)",
                flexShrink: 0,
              }} />
              <div style={{
                position: "relative",
                width: 3,
                height: 3,
                borderRadius: "50%",
                backgroundColor: "var(--colors-text-text-disabled)",
                flexShrink: 0,
              }} />
            </div>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "row",
              gap: 2,
              alignItems: "center",
              flexWrap: "nowrap",
              flexShrink: 0,
            }}>
              <div style={{
                position: "relative",
                width: 3,
                height: 3,
                borderRadius: "50%",
                backgroundColor: "var(--colors-text-text-disabled)",
                flexShrink: 0,
              }} />
              <div style={{
                position: "relative",
                width: 3,
                height: 3,
                borderRadius: "50%",
                backgroundColor: "var(--colors-text-text-disabled)",
                flexShrink: 0,
              }} />
            </div>
            <span style={{
              position: "relative",
              fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 400,
              fontSize: 14,
              lineHeight: "20px",
              color: "var(--colors-text-text-disabled)",
              textTransform: "capitalize",
              flexShrink: 0,
              whiteSpace: "nowrap",
            }}>{props.text3 ?? "1124"}</span>
          </div>
          {props.icon && (
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--colors-text-text-disabled)",
            }}>{props.icon3 ?? <Lock property1={"outline"} style={{ transform: "scale(0.667, 0.640)", transformOrigin: "0 0" }} />}</div>
          )}
        </div>
        {props.helperText && (
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 4,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 12,
              height: 12,
              flexShrink: 0,
              color: "var(--form-helpingtext-default)",
            }}>{props.icon4 ?? <Info property1={"line"} style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
          <span style={{
            position: "relative",
            fontFamily: "\"Public Sans\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 10,
            whiteSpace: "nowrap",
            lineHeight: "12px",
            color: "var(--form-helpingtext-default)",
            flexShrink: 0,
          }}>{props.text4 ?? "Helping text"}</span>
        </div>
        )}
      </div>
    </div>
  );
  const __impls = {
    // figma: Property 1=Default
    "property1=default": __body0,
    // figma: Property 1=Phone
    "property1=phone": __body1,
    // figma: Property 1=Focused
    "property1=focused": __body2,
    // figma: Property 1=Error
    "property1=error": __body3,
    // figma: Property 1=Filled
    "property1=filled": __body4,
    // figma: Property 1=Disabled
    "property1=disabled": __body5,
    // figma: Property 1=Security
    "property1=security": __body6,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default InputField;
