import * as React from 'react';
export interface InputFieldDisabledMediumProps {
  className?: string;
  style?: React.CSSProperties;
  optional?: boolean;
  rightIcon?: boolean;
  label2?: boolean;
  label?: boolean;
  /** Text content; defaults to "Label". */
  text1?: string;
  /** Text content; defaults to "(optional)". */
  text2?: string;
  /** Text content; defaults to "Value". */
  text3?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const InputFieldDisabledMedium: React.FC<InputFieldDisabledMediumProps>;
export default InputFieldDisabledMedium;
