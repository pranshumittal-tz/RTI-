import { ChevronDown } from './ChevronDown.jsx';

// figma node: 71:8805 Input Field/Disabled/Medium
export function InputFieldDisabledMedium(_p = {}) {
  const props = { ..._p, optional: _p.optional ?? false, rightIcon: _p.rightIcon ?? false, label2: _p.label2 ?? false, label: _p.label ?? false };
  return (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 8,
        backgroundColor: "var(--background-muted)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "12px 12px 12px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Value"}</span>
        <div style={{
            position: "relative",
            width: 16,
            height: 16,
            flexShrink: 0,
            color: "var(--text-disabled)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
}
export default InputFieldDisabledMedium;
