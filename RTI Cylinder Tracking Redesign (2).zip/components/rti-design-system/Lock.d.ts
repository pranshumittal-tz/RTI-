import * as React from 'react';
export interface LockProps {
  className?: string;
  style?: React.CSSProperties;
  property1?: "filled" | "outline";
}
export declare const Lock: React.FC<LockProps>;
export default Lock;
