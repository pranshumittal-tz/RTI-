// figma node: 2:116 Lock (2 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "property1=" + __venc(p.property1);

export function Lock(_p = {}) {
  const props = { ..._p, property1: _p.property1 ?? "filled" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 25,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={1.500} height={3.721} viewBox="0 0 1.500 3.721" fill="none" style={{
        position: "absolute",
        left: 11.25,
        top: 14.243,
        width: 1.5,
        height: 3.721,
      }}>
        <path d={"M 0.75 3.721 C 0.336 3.721 0 3.385 0 2.971 L 0 0.75 C 0 0.336 0.336 0 0.75 0 C 1.164 0 1.5 0.336 1.5 0.75 L 1.5 2.971 C 1.5 3.385 1.164 3.721 0.75 3.721 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={16.820} height={20.117} viewBox="0 0 16.820 20.117" fill="none" style={{
        position: "absolute",
        left: 3.59,
        top: 2.838,
        width: 16.82,
        height: 20.117,
      }}>
        <path d={"M 13.72 6.925 C 15.917 7.926 16.82 9.873 16.82 13.095 C 16.82 18.214 14.541 20.117 8.41 20.117 C 2.279 20.117 0 18.214 0 13.095 C 0 9.874 0.903 7.926 3.1 6.925 L 3.1 5.234 C 3.147 2.33 5.449 0.037 8.34 0 C 9.778 0.007 11.102 0.518 12.117 1.508 C 13.134 2.5 13.703 3.826 13.72 5.245 L 13.72 6.925 Z M 12.616 8.064 C 12.678 8.098 12.746 8.123 12.818 8.138 C 14.684 8.857 15.32 10.351 15.32 13.095 C 15.32 17.379 13.77 18.617 8.41 18.617 C 3.05 18.617 1.5 17.379 1.5 13.095 C 1.5 10.351 2.136 8.857 4.003 8.137 C 4.074 8.123 4.14 8.098 4.202 8.065 C 5.229 7.715 6.603 7.574 8.41 7.574 C 10.215 7.574 11.589 7.714 12.616 8.064 Z M 4.6 6.43 L 4.6 5.246 C 4.633 3.172 6.284 1.526 8.36 1.5 C 9.396 1.493 10.342 1.872 11.071 2.583 C 11.8 3.294 12.208 4.245 12.22 5.254 L 12.22 6.43 C 11.162 6.186 9.9 6.074 8.41 6.074 C 6.92 6.074 5.657 6.186 4.6 6.43 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 3.5,
        top: 2,
        width: 17,
        height: 20,
        overflow: "hidden",
      }}>
        <div style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: 17,
          height: 20,
          overflow: "hidden",
        }}>
          <svg width={17} height={20} viewBox="0 0 17 20" fill="none" style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: 17,
            height: 20,
          }}>
            <path d={"M 8.485 0 C 11.553 0 14.023 2.415 14.023 5.396 L 14.023 6.929 C 15.745 7.467 17 9.026 17 10.888 L 17 15.825 C 17 18.131 15.089 20 12.732 20 L 4.269 20 C 1.911 20 0 18.131 0 15.825 L 0 10.888 C 0 9.026 1.256 7.467 2.977 6.929 L 2.977 5.396 C 2.987 2.415 5.457 0 8.485 0 Z M 8.495 11.384 C 8.007 11.384 7.611 11.772 7.611 12.249 L 7.611 14.455 C 7.611 14.942 8.007 15.329 8.495 15.329 C 8.993 15.329 9.389 14.942 9.389 14.455 L 9.389 12.249 C 9.389 11.772 8.993 11.384 8.495 11.384 Z M 8.505 1.739 C 6.442 1.739 4.766 3.369 4.756 5.376 L 4.756 6.714 L 12.244 6.714 L 12.244 5.396 C 12.244 3.379 10.568 1.739 8.505 1.739 Z"} fill="currentColor" fillRule="evenodd" />
          </svg>
        </div>
      </div>
    </div>
  );
  const __impls = {
    // figma: Property 1=Outline
    "property1=outline": __body0,
    // figma: Property 1=Filled
    "property1=filled": __body1,
  };
  return (__impls[__vkey(props)] ?? __body1)();
}
export default Lock;
