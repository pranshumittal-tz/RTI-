import * as React from 'react';
export interface LucideBadgePlusProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const LucideBadgePlus: React.FC<LucideBadgePlusProps>;
export default LucideBadgePlus;
