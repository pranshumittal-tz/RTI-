import * as React from 'react';
export interface LucideCheckProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const LucideCheck: React.FC<LucideCheckProps>;
export default LucideCheck;
