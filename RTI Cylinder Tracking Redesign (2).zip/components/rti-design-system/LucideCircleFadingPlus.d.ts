import * as React from 'react';
export interface LucideCircleFadingPlusProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const LucideCircleFadingPlus: React.FC<LucideCircleFadingPlusProps>;
export default LucideCircleFadingPlus;
