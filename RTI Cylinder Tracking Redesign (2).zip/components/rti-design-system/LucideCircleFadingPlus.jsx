// figma node: 47:4060 lucide/circle-fading-plus
export function LucideCircleFadingPlus(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--foreground)",
      ...props.style,
    }}>
      <svg width={20.002} height={20} viewBox="0 0 20.002 20" fill="none" style={{
        position: "absolute",
        left: 2,
        top: 2,
        width: 20.002,
        height: 20,
      }}>
        <path d={"M 10 0 C 11.94 0 13.838 0.564 15.464 1.623 C 17.089 2.683 18.371 4.193 19.153 5.968 C 19.935 7.743 20.184 9.708 19.869 11.623 C 19.555 13.537 18.69 15.319 17.38 16.75 Z"} fill="currentColor" fillRule="evenodd" />
        <path d={"M 10 6 L 10 14 Z"} fill="currentColor" fillRule="evenodd" />
        <path d={"M 14 10 L 6 10 Z"} fill="currentColor" fillRule="evenodd" />
        <path d={"M 0.5 6.875 C 0.181 7.844 0.013 8.855 0 9.875 Z"} fill="currentColor" fillRule="evenodd" />
        <path d={"M 0.83 14 C 1.392 15.292 2.22 16.45 3.26 17.4 Z"} fill="currentColor" fillRule="evenodd" />
        <path d={"M 2.636 3.235 C 2.915 2.931 3.213 2.645 3.527 2.378 Z"} fill="currentColor" fillRule="evenodd" />
        <path d={"M 6.644 19.42 C 9.138 20.308 11.882 20.172 14.275 19.04 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
    </div>
  );
}
export default LucideCircleFadingPlus;
