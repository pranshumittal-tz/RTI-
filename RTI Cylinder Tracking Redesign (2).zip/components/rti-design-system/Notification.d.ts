import * as React from 'react';
export interface NotificationProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Notification: React.FC<NotificationProps>;
export default Notification;
