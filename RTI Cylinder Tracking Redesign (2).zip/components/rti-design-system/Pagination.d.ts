import * as React from 'react';
export interface PaginationProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Pagination: React.FC<PaginationProps>;
export default Pagination;
