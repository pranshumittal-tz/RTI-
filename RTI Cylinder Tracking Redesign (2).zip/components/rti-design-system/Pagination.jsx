import { ButtonGroupButton } from './ButtonGroupButton.jsx';

// figma node: 47:5249 Pagination
export function Pagination(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 550,
      borderRadius: 14,
      backgroundColor: "var(--background)",
      borderTop: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      borderBottom: "1px solid var(--border)",
      borderLeft: "1px solid var(--border)",
      display: "flex",
      flexDirection: "column",
      gap: 48,
      padding: "56px 56px 56px 56px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 16,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "column",
          gap: 8,
          alignItems: "flex-start",
          flexWrap: "nowrap",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 30,
            lineHeight: "36px",
            color: "var(--foreground)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>Pagination</span>
          <span style={{
            position: "relative",
            fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 16,
            lineHeight: "24px",
            color: "var(--muted-foreground)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>Pagination with page navigation, next and previous links.</span>
        </div>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 18,
        borderTop: "1px solid var(--border)",
        borderRight: "1px solid var(--border)",
        borderBottom: "1px solid var(--border)",
        borderLeft: "1px solid var(--border)",
        display: "flex",
        flexDirection: "column",
        gap: 10,
        padding: "40px 40px 40px 40px",
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 2,
          alignItems: "center",
          flexWrap: "nowrap",
          flexShrink: 0,
        }}>
          <ButtonGroupButton
            style={{
              position: "relative",
              height: 32,
              width: 32,
              flexShrink: 0,
            }}
            text1={"1"}
            variant={"ghost"}
            roundness={"default"}
            size={"default"}
            position={"single"}
            state={"default"}
          />
          <ButtonGroupButton
            style={{
              position: "relative",
              height: 32,
              width: 32,
              flexShrink: 0,
            }}
            text1={"2"}
            variant={"outline"}
            roundness={"default"}
            size={"default"}
            position={"single"}
            state={"default"}
          />
          <ButtonGroupButton
            style={{
              position: "relative",
              height: 32,
              width: 32,
              flexShrink: 0,
            }}
            text1={"3"}
            variant={"ghost"}
            roundness={"default"}
            size={"default"}
            position={"single"}
            state={"default"}
          />
          <ButtonGroupButton
            style={{
              position: "relative",
              height: 32,
              width: 32,
              flexShrink: 0,
            }}
            text1={"4"}
            variant={"ghost"}
            roundness={"default"}
            size={"default"}
            position={"single"}
            state={"default"}
          />
          <ButtonGroupButton
            style={{
              position: "relative",
              height: 32,
              width: 32,
              flexShrink: 0,
            }}
            text1={"5"}
            variant={"ghost"}
            roundness={"default"}
            size={"default"}
            position={"single"}
            state={"default"}
          />
        </div>
      </div>
    </div>
  );
}
export default Pagination;
