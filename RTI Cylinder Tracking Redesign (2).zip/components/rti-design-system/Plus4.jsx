// figma node: 55:7552 Plus 4
export function Plus4(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <svg width={10} height={1.500} viewBox="0 -0.750 10 1.500" fill="none" style={{
        position: "absolute",
        left: 5,
        top: 10,
        width: 10,
        height: 1.5,
      }}>
        <path d={"M 0 -0.75 C -0.414 -0.75 -0.75 -0.414 -0.75 0 C -0.75 0.414 -0.414 0.75 0 0.75 L 0 0 L 0 -0.75 Z M 10 0.75 C 10.414 0.75 10.75 0.414 10.75 0 C 10.75 -0.414 10.414 -0.75 10 -0.75 L 10 0 L 10 0.75 Z M 0 0 L 0 0.75 L 10 0.75 L 10 0 L 10 -0.75 L 0 -0.75 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={1.500} height={10} viewBox="-0.750 0 1.500 10" fill="none" style={{
        position: "absolute",
        left: 10,
        top: 5,
        width: 1.5,
        height: 10,
      }}>
        <path d={"M 0.75 0 C 0.75 -0.414 0.414 -0.75 0 -0.75 C -0.414 -0.75 -0.75 -0.414 -0.75 0 L 0 0 L 0.75 0 Z M -0.75 10 C -0.75 10.414 -0.414 10.75 0 10.75 C 0.414 10.75 0.75 10.414 0.75 10 L 0 10 L -0.75 10 Z M 0 0 L -0.75 0 L -0.75 10 L 0 10 L 0.75 10 L 0.75 0 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
    </div>
  );
}
export default Plus4;
