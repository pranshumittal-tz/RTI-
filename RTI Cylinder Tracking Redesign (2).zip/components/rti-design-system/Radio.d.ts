import * as React from 'react';
export interface RadioProps {
  className?: string;
  style?: React.CSSProperties;
  disabled?: boolean;
  checked?: boolean;
}
export declare const Radio: React.FC<RadioProps>;
export default Radio;
