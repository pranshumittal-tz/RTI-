// figma node: 78:9280 Radio (4 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "disabled=" + __venc(p.disabled) + '|' + "checked=" + __venc(p.checked);

export function Radio(_p = {}) {
  const props = { ..._p, disabled: _p.disabled ?? true, checked: _p.checked ?? true };
  const __body0 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 10,
      padding: "2px 0px 2px 0px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 16,
        borderRadius: "50%",
        backgroundColor: "var(--color-neutral-0)",
        boxShadow: "inset 0 0 0 1.500px var(--color-neutral-300)",
        flexShrink: 0,
        alignSelf: "stretch",
      }} />
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      backgroundColor: "rgb(255,255,255)",
      display: "flex",
      flexDirection: "row",
      gap: 10,
      padding: "2px 0px 2px 0px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 16,
        borderRadius: "50%",
        backgroundColor: "var(--color-neutral-100)",
        boxShadow: "inset 0 0 0 1.500px var(--color-neutral-300)",
        flexShrink: 0,
        alignSelf: "stretch",
      }} />
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 10,
      padding: "2px 0px 2px 0px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 16,
        borderRadius: "50%",
        backgroundColor: "var(--color-neutral-0)",
        boxShadow: "inset 0 0 0 5px var(--color-brand-500)",
        flexShrink: 0,
        alignSelf: "stretch",
      }} />
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 10,
      padding: "2px 0px 2px 0px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        width: 16,
        borderRadius: "50%",
        backgroundColor: "var(--color-neutral-500)",
        boxShadow: "inset 0 0 0 5px var(--color-neutral-200)",
        flexShrink: 0,
        alignSelf: "stretch",
      }} />
    </div>
  );
  const __impls = {
    // figma: Disabled=False, Checked=False
    "disabled=false|checked=false": __body0,
    // figma: Disabled=True, Checked=False
    "disabled=true|checked=false": __body1,
    // figma: Disabled=False, Checked=True
    "disabled=false|checked=true": __body2,
    // figma: Disabled=True, Checked=True
    "disabled=true|checked=true": __body3,
  };
  return (__impls[__vkey(props)] ?? __body3)();
}
export default Radio;
