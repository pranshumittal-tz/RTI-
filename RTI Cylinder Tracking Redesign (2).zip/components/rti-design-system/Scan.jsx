// figma node: 27:1335 Scan
export function Scan(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "var(--color-neutral-700)",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 1.25,
        top: 2.792,
        width: 17.5,
        height: 14.385,
        overflow: "hidden",
      }}>
        <div style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: 17.5,
          height: 14.385,
          overflow: "hidden",
        }}>
          <svg width={17.500} height={1.500} viewBox="0 -0.750 17.500 1.500" fill="none" style={{
            position: "absolute",
            left: 0,
            top: 7.88,
            width: 17.5,
            height: 1.5,
          }}>
            <path d={"M 17.5 0.75 C 17.914 0.75 18.25 0.414 18.25 0 C 18.25 -0.414 17.914 -0.75 17.5 -0.75 L 17.5 0 L 17.5 0.75 Z M 0 -0.75 C -0.414 -0.75 -0.75 -0.414 -0.75 0 C -0.75 0.414 -0.414 0.75 0 0.75 L 0 0 L 0 -0.75 Z M 17.5 0 L 17.5 -0.75 L 0 -0.75 L 0 0 L 0 0.75 L 17.5 0.75 L 17.5 0 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
          <svg width={4.115} height={4.371} viewBox="0 0 4.115 4.371" fill="none" style={{
            position: "absolute",
            left: 11.827,
            top: 0,
            width: 4.115,
            height: 4.371,
          }}>
            <path d={"M 3.365 4.371 C 3.365 4.785 3.701 5.121 4.115 5.121 C 4.529 5.121 4.865 4.785 4.865 4.371 L 4.115 4.371 L 3.365 4.371 Z M 0 -0.75 C -0.414 -0.75 -0.75 -0.414 -0.75 0 C -0.75 0.414 -0.414 0.75 0 0.75 L 0 0 L 0 -0.75 Z M 4.115 4.371 L 4.865 4.371 L 4.865 3.11 L 4.115 3.11 L 3.365 3.11 L 3.365 4.371 L 4.115 4.371 Z M 4.115 3.11 L 4.865 3.11 C 4.865 0.978 3.137 -0.75 1.004 -0.75 L 1.004 0 L 1.004 0.75 C 2.308 0.75 3.365 1.807 3.365 3.11 L 4.115 3.11 Z M 1.004 0 L 1.004 -0.75 L 0 -0.75 L 0 0 L 0 0.75 L 1.004 0.75 L 1.004 0 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
          <svg width={4.141} height={4.371} viewBox="0 0 4.141 4.371" fill="none" style={{
            position: "absolute",
            left: 1.558,
            top: 0,
            width: 4.141,
            height: 4.371,
          }}>
            <path d={"M -0.75 4.371 C -0.75 4.785 -0.414 5.121 0 5.121 C 0.414 5.121 0.75 4.785 0.75 4.371 L 0 4.371 L -0.75 4.371 Z M 4.141 0.75 C 4.555 0.75 4.891 0.414 4.891 0 C 4.891 -0.414 4.555 -0.75 4.141 -0.75 L 4.141 0 L 4.141 0.75 Z M 0 4.371 L 0.75 4.371 L 0.75 3.11 L 0 3.11 L -0.75 3.11 L -0.75 4.371 L 0 4.371 Z M 0 3.11 L 0.75 3.11 C 0.75 1.807 1.807 0.75 3.111 0.75 L 3.111 0 L 3.111 -0.75 C 0.978 -0.75 -0.75 0.978 -0.75 3.11 L 0 3.11 Z M 3.111 0 L 3.111 0.75 L 4.141 0.75 L 4.141 0 L 4.141 -0.75 L 3.111 -0.75 L 3.111 0 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
          <svg width={4.115} height={6.506} viewBox="0 0 4.115 6.506" fill="none" style={{
            position: "absolute",
            left: 11.827,
            top: 7.879,
            width: 4.115,
            height: 6.506,
          }}>
            <path d={"M 4.865 0 C 4.865 -0.414 4.529 -0.75 4.115 -0.75 C 3.701 -0.75 3.365 -0.414 3.365 0 L 4.115 0 L 4.865 0 Z M 0 5.756 C -0.414 5.756 -0.75 6.092 -0.75 6.506 C -0.75 6.92 -0.414 7.256 0 7.256 L 0 6.506 L 0 5.756 Z M 4.115 0 L 3.365 0 L 3.365 3.395 L 4.115 3.395 L 4.865 3.395 L 4.865 0 L 4.115 0 Z M 4.115 3.395 L 3.365 3.395 C 3.365 4.699 2.308 5.756 1.004 5.756 L 1.004 6.506 L 1.004 7.256 C 3.137 7.256 4.865 5.528 4.865 3.395 L 4.115 3.395 Z M 1.004 6.506 L 1.004 5.756 L 0 5.756 L 0 6.506 L 0 7.256 L 1.004 7.256 L 1.004 6.506 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
          <svg width={4.141} height={6.506} viewBox="0 0 4.141 6.506" fill="none" style={{
            position: "absolute",
            left: 1.558,
            top: 7.879,
            width: 4.141,
            height: 6.506,
          }}>
            <path d={"M 0.75 0 C 0.75 -0.414 0.414 -0.75 0 -0.75 C -0.414 -0.75 -0.75 -0.414 -0.75 0 L 0 0 L 0.75 0 Z M 4.141 7.256 C 4.555 7.256 4.891 6.92 4.891 6.506 C 4.891 6.092 4.555 5.756 4.141 5.756 L 4.141 6.506 L 4.141 7.256 Z M 0 0 L -0.75 0 L -0.75 3.395 L 0 3.395 L 0.75 3.395 L 0.75 0 L 0 0 Z M 0 3.395 L -0.75 3.395 C -0.75 5.528 0.978 7.256 3.111 7.256 L 3.111 6.506 L 3.111 5.756 C 1.807 5.756 0.75 4.699 0.75 3.395 L 0 3.395 Z M 3.111 6.506 L 3.111 7.256 L 4.141 7.256 L 4.141 6.506 L 4.141 5.756 L 3.111 5.756 L 3.111 6.506 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
        </div>
      </div>
    </div>
  );
}
export default Scan;
