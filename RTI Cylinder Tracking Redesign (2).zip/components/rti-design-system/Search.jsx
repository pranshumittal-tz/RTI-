// figma node: 31:1482 Search
export function Search(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 20,
      height: 20,
      overflow: "hidden",
      position: "relative",
      color: "rgb(0,0,0)",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 2.315,
        top: 2.315,
        width: 15.637,
        height: 16.018,
        overflow: "hidden",
      }}>
        <div style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: 15.637,
          height: 16.018,
          overflow: "hidden",
        }}>
          <svg width={14.981} height={14.981} viewBox="0 0 14.981 14.981" fill="none" style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: 14.981,
            height: 14.981,
          }}>
            <path d={"M 14.981 7.49 L 14.231 7.49 C 14.231 11.213 11.213 14.231 7.49 14.231 L 7.49 14.981 L 7.49 15.731 C 12.042 15.731 15.731 12.042 15.731 7.49 L 14.981 7.49 Z M 7.49 14.981 L 7.49 14.231 C 3.768 14.231 0.75 11.213 0.75 7.49 L 0 7.49 L -0.75 7.49 C -0.75 12.042 2.939 15.731 7.49 15.731 L 7.49 14.981 Z M 0 7.49 L 0.75 7.49 C 0.75 3.768 3.768 0.75 7.49 0.75 L 7.49 0 L 7.49 -0.75 C 2.939 -0.75 -0.75 2.939 -0.75 7.49 L 0 7.49 Z M 7.49 0 L 7.49 0.75 C 11.213 0.75 14.231 3.768 14.231 7.49 L 14.981 7.49 L 15.731 7.49 C 15.731 2.939 12.042 -0.75 7.49 -0.75 L 7.49 0 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
          <svg width={2.937} height={2.929} viewBox="0 0 2.937 2.929" fill="none" style={{
            position: "absolute",
            left: 12.7,
            top: 13.089,
            width: 2.937,
            height: 2.929,
          }}>
            <path d={"M 0.53 -0.531 C 0.236 -0.824 -0.239 -0.823 -0.531 -0.53 C -0.824 -0.236 -0.823 0.239 -0.53 0.531 L 0 0 L 0.53 -0.531 Z M 2.407 3.46 C 2.7 3.753 3.175 3.752 3.468 3.459 C 3.76 3.165 3.76 2.691 3.466 2.398 L 2.937 2.929 L 2.407 3.46 Z M 0 0 L -0.53 0.531 L 2.407 3.46 L 2.937 2.929 L 3.466 2.398 L 0.53 -0.531 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
          </svg>
        </div>
      </div>
    </div>
  );
}
export default Search;
