import * as React from 'react';
export interface Search1Props {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Search1: React.FC<Search1Props>;
export default Search1;
