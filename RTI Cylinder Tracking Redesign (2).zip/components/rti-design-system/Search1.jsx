// figma node: 1:134 Search 1
export function Search1(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      color: "var(--color-greyscale-100)",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 2.25,
        top: 2.25,
        width: 19.071,
        height: 19.5,
        overflow: "hidden",
      }}>
        <svg width={18.334} height={18.334} viewBox="0 0 18.334 18.334" fill="none" style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: 18.334,
          height: 18.334,
        }}>
          <path d={"M 1.5 9.167 C 1.5 4.933 4.933 1.5 9.167 1.5 M 9.167 16.834 C 4.933 16.834 1.5 13.402 1.5 9.167 M 16.834 9.167 C 16.834 13.402 13.402 16.834 9.167 16.834 M 9.167 1.5 C 13.402 1.5 16.834 4.933 16.834 9.167 Z M 9.167 0 C 4.104 0 0 4.104 0 9.167 M 18.334 9.167 C 18.334 4.104 14.23 0 9.167 0 M 9.167 18.334 C 14.23 18.334 18.334 14.23 18.334 9.167 M 0 9.167 C 0 14.23 4.104 18.334 9.167 18.334 Z"} fill="currentColor" fillRule="nonzero" />
        </svg>
        <svg width={4.800} height={4.791} viewBox="0 0 4.800 4.791" fill="none" style={{
          position: "absolute",
          left: 14.271,
          top: 14.709,
          width: 4.8,
          height: 4.791,
        }}>
          <path d={"M 1.28 0.219 C 0.986 -0.074 0.511 -0.073 0.219 0.22 M 4.58 3.51 L 1.28 0.219 M 4.581 4.571 C 4.874 4.278 4.873 3.803 4.58 3.51 M 3.52 4.572 C 3.814 4.865 4.289 4.864 4.581 4.571 M 0.22 1.281 L 3.52 4.572 M 0.219 0.22 C -0.074 0.514 -0.073 0.989 0.22 1.281 Z"} fill="currentColor" fillRule="nonzero" />
        </svg>
      </div>
    </div>
  );
}
export default Search1;
