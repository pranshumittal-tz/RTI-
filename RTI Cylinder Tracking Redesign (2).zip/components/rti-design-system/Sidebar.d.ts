import * as React from 'react';
export interface SidebarProps {
  className?: string;
  style?: React.CSSProperties;
  property1?: "default" | "collapsed";
  /** Text content; defaults to "RTI". */
  text1?: string;
  /** Text content; defaults to "MAIN". */
  text2?: string;
  /** Text content; defaults to "Dashboard". */
  text3?: string;
  /** Text content; defaults to "OPERATIONS". */
  text4?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon3?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon4?: React.ReactNode;
}
export declare const Sidebar: React.FC<SidebarProps>;
export default Sidebar;
