import * as React from 'react';
export interface SidebarPanelProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const SidebarPanel: React.FC<SidebarPanelProps>;
export default SidebarPanel;
