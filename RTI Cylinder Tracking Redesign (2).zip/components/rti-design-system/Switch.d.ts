import * as React from 'react';
export interface SwitchProps {
  className?: string;
  style?: React.CSSProperties;
  toggle?: "off" | "on";
  state?: "active" | "hover" | "disabled";
}
export declare const Switch: React.FC<SwitchProps>;
export default Switch;
