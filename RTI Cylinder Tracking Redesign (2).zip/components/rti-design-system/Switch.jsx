// figma node: 75:9137 Switch (6 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "toggle=" + __venc(p.toggle) + '|' + "state=" + __venc(p.state);

export function Switch(_p = {}) {
  const props = { ..._p, toggle: _p.toggle ?? "off", state: _p.state ?? "active" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "rgb(231,231,231)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 1.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "rgb(255,255,255)",
      }} />
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "rgb(231,231,231)",
      boxShadow: "0px 2px 5px 0px rgba(103,110,118,0.08), 0px 0px 0px 1px rgba(103,110,118,0.24), 0px 1px 1px 0px rgba(0,0,0,0.12)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 1.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "rgb(255,255,255)",
      }} />
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "var(--color-neutral-200)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 1.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "var(--color-neutral-50)",
      }} />
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "var(--color-neutral-400)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 15.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "var(--color-neutral-50)",
      }} />
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "var(--color-brand-500)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 15.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "rgb(255,255,255)",
      }} />
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "var(--color-brand-500)",
      boxShadow: "0px 2px 5px 0px rgba(103,110,118,0.08), 0px 0px 0px 1px rgb(229,203,190), 0px 1px 1px 0px rgba(0,0,0,0.12)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 15.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "rgb(255,255,255)",
      }} />
    </div>
  );
  const __impls = {
    // figma: Toggle=OFF, State=Active
    "toggle=off|state=active": __body0,
    // figma: Toggle=OFF, State=Hover
    "toggle=off|state=hover": __body1,
    // figma: Toggle=OFF, State=Disabled
    "toggle=off|state=disabled": __body2,
    // figma: Toggle=ON, State=Disabled
    "toggle=on|state=disabled": __body3,
    // figma: Toggle=ON, State=Active
    "toggle=on|state=active": __body4,
    // figma: Toggle=ON, State=Hover
    "toggle=on|state=hover": __body5,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Switch;
