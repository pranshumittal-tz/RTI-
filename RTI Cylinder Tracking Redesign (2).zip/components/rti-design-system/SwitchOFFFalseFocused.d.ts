import * as React from 'react';
export interface SwitchOFFFalseFocusedProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const SwitchOFFFalseFocused: React.FC<SwitchOFFFalseFocusedProps>;
export default SwitchOFFFalseFocused;
