// figma node: 109:7325 Switch/OFF/False/Focused
export function SwitchOFFFalseFocused(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 32,
      height: 18,
      overflow: "hidden",
      borderRadius: 23,
      backgroundColor: "rgb(231,231,231)",
      boxShadow: "0px 2px 5px 0px rgba(103,110,118,0.08), 0px 0px 0px 1px rgba(103,110,118,0.24), 0px 1px 1px 0px rgba(0,0,0,0.12)",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 1.72,
        top: 2,
        width: 14,
        height: 14,
        borderRadius: "50%",
        backgroundColor: "rgb(255,255,255)",
      }} />
    </div>
  );
}
export default SwitchOFFFalseFocused;
