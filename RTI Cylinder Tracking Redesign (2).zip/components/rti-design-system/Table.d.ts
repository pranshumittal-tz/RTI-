import * as React from 'react';
export interface TableProps {
  className?: string;
  style?: React.CSSProperties;
  property1?: "default" | "row selected";
  /** Text content; defaults to "Outbound Date". */
  text1?: string;
  /** Text content; defaults to "Barcode". */
  text2?: string;
  /** Text content; defaults to "Serial Number". */
  text3?: string;
  /** Text content; defaults to "Container Size". */
  text4?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon2?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon3?: React.ReactNode;
  /** Swappable nested instance; defaults to the design's. */
  icon4?: React.ReactNode;
}
export declare const Table: React.FC<TableProps>;
export default Table;
