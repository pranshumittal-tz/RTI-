import { Checkbox } from './Checkbox.jsx';
import { ChevronDown } from './ChevronDown.jsx';
import { Edit } from './Edit.jsx';
import { Switch } from './Switch.jsx';

// figma node: 116:8190 Table (2 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "property1=" + __venc(p.property1);

export function Table(_p = {}) {
  const props = { ..._p, property1: _p.property1 ?? "default" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 1120,
      overflow: "hidden",
      borderRadius: 12,
      boxShadow: "inset 0 0 0 1px var(--border-color-default)",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      color: "var(--color-red-300)",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        backgroundColor: "var(--color-neutral-25)",
        borderTop: "1px solid var(--border-color-default)",
        borderRight: "1px solid var(--border-color-default)",
        borderBottom: "1px solid var(--border-color-default)",
        borderLeft: "1px solid var(--border-color-default)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon1 ?? <Checkbox interaction={"default"} dataState={"unchecked"} />}</div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          padding: "12px 16px 12px 16px",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text1 ?? "Outbound Date"}</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
            }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          padding: "12px 16px 12px 16px",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text2 ?? "Barcode"}</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text3 ?? "Serial Number"}</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          padding: "12px 16px 12px 16px",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text4 ?? "Container Size"}</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
            }}>{props.icon3 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>Deposit</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>Amount</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
            }}>{props.icon4 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>Actions</span>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        borderTop: "1px solid var(--border-color-strong)",
        borderRight: "1px solid var(--border-color-strong)",
        borderBottom: "1px solid var(--border-color-strong)",
        borderLeft: "1px solid var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>12012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>482321133</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>25</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        borderTop: "1px solid var(--border-color-strong)",
        borderRight: "1px solid var(--border-color-strong)",
        borderBottom: "1px solid var(--border-color-strong)",
        borderLeft: "1px solid var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>65012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>482321144</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>25</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        borderTop: "1px solid var(--border-color-strong)",
        borderRight: "1px solid var(--border-color-strong)",
        borderBottom: "1px solid var(--border-color-strong)",
        borderLeft: "1px solid var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>78012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>482321634</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>60</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>10012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>481321134</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>60</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 1120,
      overflow: "hidden",
      borderRadius: 12,
      boxShadow: "inset 0 0 0 1px var(--border-color-default)",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      color: "var(--color-red-300)",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        backgroundColor: "var(--color-neutral-25)",
        borderTop: "1px solid var(--border-color-default)",
        borderRight: "1px solid var(--border-color-default)",
        borderBottom: "1px solid var(--border-color-default)",
        borderLeft: "1px solid var(--border-color-default)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}>{props.icon1 ?? <Checkbox interaction={"default"} dataState={"unchecked"} />}</div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          padding: "12px 16px 12px 16px",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text1 ?? "Outbound Date"}</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
            }}>{props.icon2 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          padding: "12px 16px 12px 16px",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text2 ?? "Barcode"}</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text3 ?? "Serial Number"}</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          padding: "12px 16px 12px 16px",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>{props.text4 ?? "Container Size"}</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
            }}>{props.icon3 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>Deposit</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>Amount</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
            }}>{props.icon4 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
          }}>Actions</span>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        borderTop: "1px solid var(--border-color-strong)",
        borderRight: "1px solid var(--border-color-strong)",
        borderBottom: "1px solid var(--border-color-strong)",
        borderLeft: "1px solid var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>12012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>482321133</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>25</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-canvas)",
        borderTop: "1px solid var(--border-color-strong)",
        borderRight: "1px solid var(--border-color-strong)",
        borderBottom: "1px solid var(--border-color-strong)",
        borderLeft: "1px solid var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"checked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>65012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>482321144</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>25</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        borderTop: "1px solid var(--border-color-strong)",
        borderRight: "1px solid var(--border-color-strong)",
        borderBottom: "1px solid var(--border-color-strong)",
        borderLeft: "1px solid var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>78012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>482321634</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>60</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
      <div style={{
        position: "relative",
        backgroundColor: "var(--background-surface)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Checkbox
            style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            interaction={"default"}
            dataState={"unchecked"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>07/02/2026</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "row",
            gap: 8,
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 500,
              fontSize: 13,
              whiteSpace: "nowrap",
              lineHeight: "18px",
              color: "var(--text-primary)",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>10012341</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>481321134</span>
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 13,
            whiteSpace: "nowrap",
            lineHeight: "18px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>60</span>
        </div>
        <div style={{
          position: "relative",
          width: 117,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Switch
            style={{
              position: "relative",
              width: 32,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }}
            toggle={"off"}
            state={"active"}
          />
        </div>
        <div style={{
          position: "relative",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 500,
            fontSize: 12,
            whiteSpace: "nowrap",
            lineHeight: "16px",
            color: "var(--text-secondary)",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>$-</span>
        </div>
        <div style={{
          position: "relative",
          width: 80,
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "12px 16px 12px 16px",
          justifyContent: "flex-end",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <Edit style={{
              position: "relative",
              width: 16,
              flexShrink: 0,
              alignSelf: "stretch",
              height: "auto",
            }} />
          <div style={{
            position: "relative",
            width: 16,
            overflow: "hidden",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <svg width={4.611} height={7.635} viewBox="0 0 4.611 7.635" fill="none" style={{
              position: "absolute",
              left: 3.557,
              top: 6.365,
              width: 4.611,
              height: 7.635,
            }}>
              <path d={"M 0.499 -0.036 C 0.479 -0.312 0.239 -0.519 -0.036 -0.499 C -0.312 -0.479 -0.519 -0.239 -0.499 0.036 L 0 0 L 0.499 -0.036 Z M 0.408 5.584 L 0.907 5.547 L 0.907 5.547 L 0.408 5.584 Z M 4.611 8.135 C 4.887 8.135 5.111 7.911 5.111 7.635 C 5.111 7.358 4.887 7.135 4.611 7.135 L 4.611 7.635 L 4.611 8.135 Z M 0 0 L -0.499 0.036 L -0.091 5.62 L 0.408 5.584 L 0.907 5.547 L 0.499 -0.036 L 0 0 Z M 0.408 5.584 L -0.091 5.62 C 0.013 7.037 1.193 8.135 2.613 8.135 L 2.613 7.635 L 2.613 7.135 C 1.717 7.135 0.972 6.442 0.907 5.547 L 0.408 5.584 Z M 2.613 7.635 L 2.613 8.135 L 4.611 8.135 L 4.611 7.635 L 4.611 7.135 L 2.613 7.135 L 2.613 7.635 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.613} height={7.635} viewBox="0 0 2.613 7.635" fill="none" style={{
              position: "absolute",
              left: 10.165,
              top: 6.365,
              width: 2.613,
              height: 7.635,
            }}>
              <path d={"M 3.112 0.036 C 3.132 -0.239 2.925 -0.479 2.65 -0.499 C 2.374 -0.519 2.135 -0.312 2.115 -0.036 L 2.613 0 L 3.112 0.036 Z M 2.205 5.584 L 1.707 5.548 L 1.707 5.548 L 2.205 5.584 Z M 0 7.135 C -0.276 7.135 -0.5 7.358 -0.5 7.635 C -0.5 7.911 -0.276 8.135 0 8.135 L 0 7.635 L 0 7.135 Z M 2.613 0 L 2.115 -0.036 L 1.707 5.548 L 2.205 5.584 L 2.704 5.621 L 3.112 0.036 L 2.613 0 Z M 2.205 5.584 L 1.707 5.548 C 1.641 6.442 0.897 7.135 0 7.135 L 0 7.635 L 0 8.135 C 1.421 8.135 2.601 7.037 2.704 5.621 L 2.205 5.584 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={11.020} height={1} viewBox="0 -0.500 11.020 1" fill="none" style={{
              position: "absolute",
              left: 2.657,
              top: 4.267,
              width: 11.02,
              height: 1,
            }}>
              <path d={"M 11.02 0.5 C 11.296 0.5 11.52 0.276 11.52 0 C 11.52 -0.276 11.296 -0.5 11.02 -0.5 L 11.02 0 L 11.02 0.5 Z M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 11.02 0 L 11.02 -0.5 L 0 -0.5 L 0 0 L 0 0.5 L 11.02 0.5 L 11.02 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={5.026} height={2.267} viewBox="0 0 5.026 2.267" fill="none" style={{
              position: "absolute",
              left: 5.655,
              top: 2,
              width: 5.026,
              height: 2.267,
            }}>
              <path d={"M 4.536 2.367 C 4.591 2.638 4.855 2.812 5.126 2.757 C 5.396 2.703 5.571 2.439 5.516 2.168 L 5.026 2.267 L 4.536 2.367 Z M 4.691 0.617 L 5.181 0.517 C 5.179 0.507 5.176 0.497 5.174 0.488 L 4.691 0.617 Z M 1.14 0 L 1.138 0.5 L 1.14 0.5 L 1.14 0 Z M 0.332 0.617 L -0.151 0.487 C -0.154 0.498 -0.156 0.508 -0.158 0.518 L 0.332 0.617 Z M -0.49 2.169 C -0.545 2.44 -0.369 2.703 -0.099 2.758 C 0.172 2.812 0.436 2.637 0.49 2.366 L 0 2.267 L -0.49 2.169 Z M 5.026 2.267 L 5.516 2.168 L 5.181 0.517 L 4.691 0.617 L 4.201 0.716 L 4.536 2.367 L 5.026 2.267 Z M 4.691 0.617 L 5.174 0.488 C 5.018 -0.095 4.489 -0.5 3.887 -0.5 L 3.887 0 L 3.887 0.5 C 4.037 0.5 4.169 0.601 4.208 0.746 L 4.691 0.617 Z M 3.887 0 L 3.887 -0.5 L 1.14 -0.5 L 1.14 0 L 1.14 0.5 L 3.887 0.5 L 3.887 0 Z M 1.14 0 L 1.141 -0.5 C 0.537 -0.502 0.006 -0.097 -0.151 0.487 L 0.332 0.617 L 0.815 0.746 C 0.854 0.601 0.986 0.499 1.138 0.5 L 1.14 0 Z M 0.332 0.617 L -0.158 0.518 L -0.49 2.169 L 0 2.267 L 0.49 2.366 L 0.822 0.715 L 0.332 0.617 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
            <svg width={2.254} height={3.006} viewBox="0 0 2.254 3.006" fill="none" style={{
              position: "absolute",
              left: 6.901,
              top: 7.854,
              width: 2.254,
              height: 3.006,
            }}>
              <path d={"M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 3.006 C -0.5 3.282 -0.276 3.506 0 3.506 C 0.276 3.506 0.5 3.282 0.5 3.006 L 0 3.006 L -0.5 3.006 Z M 2.754 0 C 2.754 -0.276 2.53 -0.5 2.254 -0.5 C 1.977 -0.5 1.754 -0.276 1.754 0 L 2.254 0 L 2.754 0 Z M 1.754 3.006 C 1.754 3.282 1.977 3.506 2.254 3.506 C 2.53 3.506 2.754 3.282 2.754 3.006 L 2.254 3.006 L 1.754 3.006 Z M 0 0 L -0.5 0 L -0.5 3.006 L 0 3.006 L 0.5 3.006 L 0.5 0 L 0 0 Z M 2.254 0 L 1.754 0 L 1.754 3.006 L 2.254 3.006 L 2.754 3.006 L 2.754 0 L 2.254 0 Z"} fill="currentColor" fillRule="nonzero" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
  const __impls = {
    // figma: Property 1=Default
    "property1=default": __body0,
    // figma: Property 1=Row selected
    "property1=row selected": __body1,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Table;
