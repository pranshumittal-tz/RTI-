import * as React from 'react';
export interface Table2Props {
  className?: string;
  style?: React.CSSProperties;
}
export declare const Table2: React.FC<Table2Props>;
export default Table2;
