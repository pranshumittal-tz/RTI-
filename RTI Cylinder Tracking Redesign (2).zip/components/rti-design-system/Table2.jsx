import { Component1 } from './Component1.jsx';
import { Consolidation } from './Consolidation.jsx';
import { Customers } from './Customers.jsx';
import { DASHBOARD } from './DASHBOARD.jsx';
import { Scan } from './Scan.jsx';

// figma node: 116:8511 Table
export function Table2(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: "fit-content",
      backgroundColor: "var(--color-neutral-0)",
      display: "flex",
      flexDirection: "column",
      gap: 27,
      padding: "24px 24px 24px 24px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 24,
          lineHeight: "32px",
          color: "var(--color-neutral-800)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>Vertical Bar</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--muted-foreground)",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>A vertical bar i</span>
      </div>
      <div style={{
        position: "relative",
        width: 232.9,
        height: 823.64,
        backgroundColor: "var(--background-surface)",
        borderRight: "1px solid var(--border-color-subtle)",
        display: "flex",
        flexDirection: "column",
        padding: "0px 0.909px 0px 0px",
        alignItems: "flex-start",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
      }}>
        <div style={{
          position: "relative",
          height: 60,
          borderBottom: "1px solid var(--border-color-subtle)",
          display: "flex",
          flexDirection: "row",
          gap: 8,
          padding: "16px 20px 16px 20px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            width: 25.99,
            borderRadius: 8,
            backgroundColor: "var(--color-grey-7)",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <Component1
              style={{
                position: "relative",
                width: 14,
                height: 14,
                flexShrink: 0,
              }}
              variant={"1"}
            />
          </div>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "column",
            padding: "0.450px 0px 0.910px 0px",
            alignItems: "flex-start",
            flexWrap: "nowrap",
            boxSizing: "border-box",
            flexShrink: 0,
          }}>
            <span style={{
              position: "relative",
              fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
              fontWeight: 700,
              fontSize: 15,
              whiteSpace: "nowrap",
              lineHeight: "100%",
              letterSpacing: "-0.150px",
              color: "var(--color-grey-7)",
              flexShrink: 0,
            }}>RTI</span>
          </div>
        </div>
        <div style={{
          position: "relative",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          padding: "16px 12px 16px 12px",
          alignItems: "flex-start",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexGrow: 1,
          alignSelf: "stretch",
        }}>
          <div style={{
            position: "relative",
            display: "flex",
            flexDirection: "column",
            gap: 16,
            alignItems: "flex-start",
            flexWrap: "nowrap",
            flexShrink: 0,
            alignSelf: "stretch",
          }}>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "column",
              gap: 8,
              alignItems: "flex-start",
              flexWrap: "nowrap",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                padding: "0px 8px 0px 8px",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                boxSizing: "border-box",
                flexShrink: 0,
                alignSelf: "stretch",
              }}>
                <span style={{
                  position: "relative",
                  fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                  fontWeight: 500,
                  fontSize: 12,
                  lineHeight: "16px",
                  color: "var(--text-secondary)",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>MAIN</span>
              </div>
              <div style={{
                position: "relative",
                borderRadius: 8,
                display: "flex",
                flexDirection: "row",
                gap: 10,
                padding: "8px 8px 8px 8px",
                alignItems: "center",
                flexWrap: "nowrap",
                boxSizing: "border-box",
                flexShrink: 0,
                alignSelf: "stretch",
              }}>
                <div style={{
                    position: "relative",
                    width: 16,
                    height: 16,
                    flexShrink: 0,
                  }}>
                  <DASHBOARD style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                </div>
                <span style={{
                  position: "relative",
                  fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                  fontWeight: 500,
                  fontSize: 13,
                  whiteSpace: "nowrap",
                  lineHeight: "18px",
                  color: "var(--text-secondary)",
                  flexShrink: 0,
                }}>Dashboard</span>
              </div>
            </div>
            <div style={{
              position: "relative",
              display: "flex",
              flexDirection: "column",
              gap: 8,
              alignItems: "flex-start",
              flexWrap: "nowrap",
              flexShrink: 0,
              alignSelf: "stretch",
            }}>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                padding: "0px 8px 0px 8px",
                alignItems: "flex-start",
                flexWrap: "nowrap",
                boxSizing: "border-box",
                flexShrink: 0,
                alignSelf: "stretch",
              }}>
                <span style={{
                  position: "relative",
                  fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                  fontWeight: 500,
                  fontSize: 12,
                  lineHeight: "16px",
                  color: "var(--text-secondary)",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>OPERATIONS</span>
              </div>
              <div style={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                gap: 8,
                alignItems: "flex-start",
                flexWrap: "nowrap",
                flexShrink: 0,
                alignSelf: "stretch",
              }}>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  backgroundColor: "var(--color-brand-100)",
                  display: "flex",
                  flexDirection: "row",
                  gap: 8,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <Customers style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                  <span style={{
                    position: "relative",
                    fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 13,
                    whiteSpace: "nowrap",
                    lineHeight: "18px",
                    color: "var(--text-brand)",
                    flexShrink: 0,
                  }}>Customers</span>
                </div>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "row",
                  gap: 8,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <Consolidation style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                  <span style={{
                    position: "relative",
                    fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 13,
                    whiteSpace: "nowrap",
                    lineHeight: "18px",
                    color: "var(--text-secondary)",
                    flexShrink: 0,
                  }}>Consolidation</span>
                </div>
                <div style={{
                  position: "relative",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "row",
                  gap: 8,
                  padding: "8px 8px 8px 8px",
                  alignItems: "center",
                  flexWrap: "nowrap",
                  boxSizing: "border-box",
                  flexShrink: 0,
                  alignSelf: "stretch",
                }}>
                  <div style={{
                      position: "relative",
                      width: 16,
                      height: 16,
                      flexShrink: 0,
                    }}>
                    <Scan style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />
                  </div>
                  <span style={{
                    position: "relative",
                    fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
                    fontWeight: 500,
                    fontSize: 13,
                    whiteSpace: "nowrap",
                    lineHeight: "18px",
                    color: "var(--text-secondary)",
                    flexShrink: 0,
                  }}>Barcoding</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Table2;
