import * as React from 'react';
export interface TextAreaProps {
  className?: string;
  style?: React.CSSProperties;
  optional?: boolean;
  property1?: "default" | "focus" | "filled" | "disabled" | "error";
  /** Text content; defaults to "Label". */
  text1?: string;
  /** Text content; defaults to "(optional)". */
  text2?: string;
  /** Text content; defaults to "Placeholder". */
  text3?: string;
  /** Text content; defaults to "Error message". */
  text4?: string;
}
export declare const TextArea: React.FC<TextAreaProps>;
export default TextArea;
