import * as React from 'react';
export interface TextInputProps {
  className?: string;
  style?: React.CSSProperties;
  optional?: boolean;
  property1?: "default" | "focus" | "filled" | "disabled" | "error";
  rightIcon?: boolean;
  size?: "md" | "sm";
  label2?: boolean;
  label?: boolean;
  /** Text content; defaults to "Label". */
  text1?: string;
  /** Text content; defaults to "(optional)". */
  text2?: string;
  /** Text content; defaults to "Enter PO number". */
  text3?: string;
  /** Text content; defaults to "Error message". */
  text4?: string;
  /** Swappable nested instance; defaults to the design's. */
  icon1?: React.ReactNode;
}
export declare const TextInput: React.FC<TextInputProps>;
export default TextInput;
