import { ChevronDown } from './ChevronDown.jsx';

// figma node: 69:8686 Text Input (10 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "property1=" + __venc(p.property1) + '|' + "size=" + __venc(p.size);

export function TextInput(_p = {}) {
  const props = { ..._p, optional: _p.optional ?? false, property1: _p.property1 ?? "default", rightIcon: _p.rightIcon ?? false, size: _p.size ?? "md", label2: _p.label2 ?? false, label: _p.label ?? false };
  const __body0 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 8,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "12px 12px 12px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-placeholder)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Enter PO number"}</span>
        <div style={{
            position: "relative",
            width: 16,
            height: 16,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          borderRadius: 8,
          backgroundColor: "var(--background-surface)",
          boxShadow: "inset 0 0 0 1px var(--color-red-200)",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "12px 12px 12px 12px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 14,
            lineHeight: "20px",
            color: "var(--text-primary)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Value"}</span>
          <div style={{
              position: "relative",
              width: 16,
              height: 16,
              flexShrink: 0,
              color: "var(--text-secondary)",
            }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
        </div>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--color-red-300)",
          flexShrink: 0,
        }}>{props.text4 ?? "Error message"}</span>
      </div>
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: 130,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 6,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 8px 4px 8px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-placeholder)",
          flexShrink: 0,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Placeholder"}</span>
        <div style={{
            position: "relative",
            width: 10,
            height: 10,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: 130,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        flexWrap: "nowrap",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <div style={{
          position: "relative",
          borderRadius: 6,
          backgroundColor: "var(--background-surface)",
          boxShadow: "inset 0 0 0 1px var(--color-red-200)",
          display: "flex",
          flexDirection: "row",
          gap: 10,
          padding: "4px 8px 4px 8px",
          alignItems: "center",
          flexWrap: "nowrap",
          boxSizing: "border-box",
          flexShrink: 0,
          alignSelf: "stretch",
        }}>
          <span style={{
            position: "relative",
            fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
            fontWeight: 400,
            fontSize: 12,
            lineHeight: "16px",
            color: "var(--text-placeholder)",
            flexGrow: 1,
            whiteSpace: "nowrap",
          }}>{props.text3 ?? "Placeholder"}</span>
          <div style={{
              position: "relative",
              width: 10,
              height: 10,
              flexShrink: 0,
              color: "var(--text-secondary)",
            }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
        </div>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--color-red-300)",
          flexShrink: 0,
        }}>{props.text4 ?? "Error message"}</span>
      </div>
    </div>
  );
  const __body4 = () => (
    <div className={props.className} style={{
      width: 130,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 6,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-focus)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 8px 4px 8px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 12,
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "|"}</span>
        <div style={{
            position: "relative",
            width: 10,
            height: 10,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body5 = () => (
    <div className={props.className} style={{
      width: 130,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 6,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 8px 4px 8px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 12,
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Value"}</span>
        <div style={{
            position: "relative",
            width: 10,
            height: 10,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body6 = () => (
    <div className={props.className} style={{
      width: 130,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 12,
          whiteSpace: "nowrap",
          lineHeight: "16px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 6,
        backgroundColor: "var(--background-muted)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "4px 8px 4px 8px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 12,
          lineHeight: "16px",
          color: "var(--text-primary)",
          flexShrink: 0,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Value"}</span>
        <div style={{
            position: "relative",
            width: 10,
            height: 10,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.500, 0.500)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body7 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 8,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-focus)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "12px 12px 12px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "|"}</span>
        <div style={{
            position: "relative",
            width: 16,
            height: 16,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body8 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 8,
        backgroundColor: "var(--background-surface)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "12px 12px 12px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Value"}</span>
        <div style={{
            position: "relative",
            width: 16,
            height: 16,
            flexShrink: 0,
            color: "var(--text-secondary)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __body9 = () => (
    <div className={props.className} style={{
      width: 346,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "relative",
        display: "flex",
        flexDirection: "row",
        gap: 4,
        alignItems: "center",
        flexWrap: "nowrap",
        flexShrink: 0,
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexShrink: 0,
        }}>{props.text1 ?? "Label"}</span>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 500,
          fontSize: 14,
          whiteSpace: "nowrap",
          lineHeight: "20px",
          color: "var(--text-tertiary)",
          flexShrink: 0,
        }}>{props.text2 ?? "(optional)"}</span>
      </div>
      <div style={{
        position: "relative",
        borderRadius: 8,
        backgroundColor: "var(--background-muted)",
        boxShadow: "inset 0 0 0 1px var(--border-color-strong)",
        display: "flex",
        flexDirection: "row",
        gap: 10,
        padding: "12px 12px 12px 12px",
        alignItems: "center",
        flexWrap: "nowrap",
        boxSizing: "border-box",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>
        <span style={{
          position: "relative",
          fontFamily: "Satoshi, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          lineHeight: "20px",
          color: "var(--text-primary)",
          flexGrow: 1,
          whiteSpace: "nowrap",
        }}>{props.text3 ?? "Value"}</span>
        <div style={{
            position: "relative",
            width: 16,
            height: 16,
            flexShrink: 0,
            color: "var(--text-disabled)",
          }}>{props.icon1 ?? <ChevronDown style={{ transform: "scale(0.800, 0.800)", transformOrigin: "0 0" }} />}</div>
      </div>
    </div>
  );
  const __impls = {
    // figma: Property 1=Default, Size=Medium
    "property1=default|size=md": __body0,
    // figma: Property 1=Error, Size=Medium
    "property1=error|size=md": __body1,
    // figma: Property 1=Default, Size=Small
    "property1=default|size=sm": __body2,
    // figma: Property 1=Error, Size=Small
    "property1=error|size=sm": __body3,
    // figma: Property 1=Focus, Size=Small
    "property1=focus|size=sm": __body4,
    // figma: Property 1=Filled, Size=Small
    "property1=filled|size=sm": __body5,
    // figma: Property 1=Disabled, Size=Small
    "property1=disabled|size=sm": __body6,
    // figma: Property 1=Focus, Size=Medium
    "property1=focus|size=md": __body7,
    // figma: Property 1=Filled, Size=Medium
    "property1=filled|size=md": __body8,
    // figma: Property 1=Disabled, Size=Medium
    "property1=disabled|size=md": __body9,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default TextInput;
