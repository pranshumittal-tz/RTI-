import * as React from 'react';
export interface USFlagProps {
  className?: string;
  style?: React.CSSProperties;
}
export declare const USFlag: React.FC<USFlagProps>;
export default USFlag;
