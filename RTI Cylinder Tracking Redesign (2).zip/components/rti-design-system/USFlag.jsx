// figma node: 2:49 US Flag
export function USFlag(_p = {}) {
  const props = _p;
  return (
    <div className={props.className} style={{
      width: 24,
      height: 24,
      overflow: "hidden",
      position: "relative",
      ...props.style,
    }}>
      <div style={{
        position: "absolute",
        left: 0.05,
        top: 0,
        width: 23.9,
        height: 21.856,
        overflow: "hidden",
      }}>
        <div style={{
          position: "absolute",
          left: 0.005,
          top: 13.122,
          width: 23.893,
          height: 1,
          border: "1px dashed currentColor",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          fontSize: 10,
          opacity: 0.45,
        }}>Vector</div>
        <div style={{
          position: "absolute",
          left: 1.249,
          top: 6.572,
          width: 21.403,
          height: 1,
          border: "1px dashed currentColor",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          fontSize: 10,
          opacity: 0.45,
        }}>Vector</div>
        <div style={{
          position: "absolute",
          left: 0.398,
          top: 8.755,
          width: 23.104,
          height: 1,
          border: "1px dashed currentColor",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          fontSize: 10,
          opacity: 0.45,
        }}>Vector</div>
        <svg width={13.686} height={0.001} viewBox="0 0 13.686 0.001" fill="none" style={{
          position: "absolute",
          left: 5.107,
          top: 21.855,
          width: 13.686,
          height: 0.001,
          color: "rgb(196,33,38)",
        }}>
          <path d={"M 0.001 0.001 L 13.686 0.001 L 13.686 0 L 0 0 L 0.001 0.001 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.403} height={0.022} viewBox="0 0 1.403 0.022" fill="none" style={{
          position: "absolute",
          left: 11.249,
          top: 0,
          width: 1.403,
          height: 0.022,
          color: "rgb(196,33,38)",
        }}>
          <path d={"M 0.702 0 C 0.466 0 0.232 0.009 0 0.022 L 1.403 0.022 C 1.171 0.009 0.937 0 0.702 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <div style={{
          position: "absolute",
          left: 0,
          top: 10.939,
          width: 23.9,
          height: 1,
          border: "1px dashed currentColor",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          fontSize: 10,
          opacity: 0.45,
        }}>Vector</div>
      </div>
      <svg width={6.651} height={2.183} viewBox="0 0 6.651 2.183" fill="none" style={{
        position: "absolute",
        left: 14.626,
        top: 2.205,
        width: 6.651,
        height: 2.183,
        color: "rgb(231,231,231)",
      }}>
        <path d={"M 0.921 2.183 L 6.651 2.183 C 5.97 1.354 5.179 0.621 4.303 0 L 0 0 C 0.356 0.626 0.662 1.366 0.921 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={6.597} height={2.184} viewBox="0 0 6.597 2.184" fill="none" style={{
        position: "absolute",
        left: 12.332,
        top: 0.022,
        width: 6.597,
        height: 2.184,
        color: "rgb(220,48,39)",
      }}>
        <path d={"M 2.294 2.184 L 6.597 2.184 C 4.818 0.923 2.682 0.134 0.369 0 L 0 0 C 1.089 0.137 1.589 0.943 2.294 2.184 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.443} height={2.183} viewBox="0 0 7.443 2.183" fill="none" style={{
        position: "absolute",
        left: 16.109,
        top: 6.572,
        width: 7.443,
        height: 2.183,
        color: "rgb(231,231,231)",
      }}>
        <path d={"M 7.443 2.183 C 7.23 1.422 6.944 0.692 6.592 0 L 0 0 C 0.134 0.701 0.239 1.433 0.317 2.183 L 7.443 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.507} height={2.183} viewBox="0 0 7.507 2.183" fill="none" style={{
        position: "absolute",
        left: 15.194,
        top: 4.388,
        width: 7.507,
        height: 2.183,
        color: "rgb(220,48,39)",
      }}>
        <path d={"M 0.544 2.183 L 7.507 2.183 C 7.11 1.403 6.633 0.671 6.082 0 L 0 0 C 0.214 0.679 0.397 1.411 0.544 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.321} height={2.183} viewBox="0 0 7.321 2.183" fill="none" style={{
        position: "absolute",
        left: 16.679,
        top: 10.939,
        width: 7.321,
        height: 2.183,
        color: "rgb(231,231,231)",
      }}>
        <path d={"M 0 2.183 L 7.267 2.183 C 7.302 1.814 7.321 1.44 7.321 1.061 C 7.321 0.704 7.303 0.35 7.272 0 L 0.002 0 C 0.025 0.726 0.025 1.457 0 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.831} height={2.183} viewBox="0 0 7.831 2.183" fill="none" style={{
        position: "absolute",
        left: 16.12,
        top: 8.755,
        width: 7.831,
        height: 2.183,
        color: "rgb(220,48,39)",
      }}>
        <path d={"M 7.831 2.183 C 7.765 1.433 7.63 0.704 7.433 0 L 0 0 C 0.075 0.715 0.124 1.446 0.148 2.183 L 7.831 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.551} height={2.183} viewBox="0 0 7.551 2.183" fill="none" style={{
        position: "absolute",
        left: 15.984,
        top: 15.305,
        width: 7.551,
        height: 2.183,
        color: "rgb(231,231,231)",
      }}>
        <path d={"M 0 2.183 L 6.686 2.183 C 7.043 1.492 7.333 0.761 7.551 0 L 0.323 0 C 0.244 0.751 0.136 1.483 0 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={7.646} height={2.183} viewBox="0 0 7.646 2.183" fill="none" style={{
        position: "absolute",
        left: 16.3,
        top: 13.122,
        width: 7.646,
        height: 2.183,
        color: "rgb(220,48,39)",
      }}>
        <path d={"M 7.236 2.183 C 7.437 1.479 7.577 0.75 7.646 0 L 0.153 0 C 0.127 0.737 0.076 1.468 0 2.183 L 7.236 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={6.568} height={2.183} viewBox="0 0 6.568 2.183" fill="none" style={{
        position: "absolute",
        left: 14.658,
        top: 19.672,
        width: 6.568,
        height: 2.183,
        color: "rgb(231,231,231)",
      }}>
        <path d={"M 4.186 2.183 C 5.075 1.565 5.877 0.83 6.568 0 L 0.938 0 C 0.675 0.821 0.362 1.559 0 2.183 L 4.186 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <div style={{
        position: "absolute",
        left: 11.492,
        top: 17.489,
        width: 11.178,
        height: 6.511,
        overflow: "hidden",
      }}>
        <svg width={7.286} height={2.183} viewBox="0 0 7.286 2.183" fill="none" style={{
          position: "absolute",
          left: 3.892,
          top: 0,
          width: 7.286,
          height: 2.183,
          color: "rgb(220,48,39)",
        }}>
          <path d={"M 0 2.183 L 5.842 2.183 C 6.4 1.514 6.883 0.781 7.286 0 L 0.551 0 C 0.401 0.773 0.217 1.505 0 2.183 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={0.073} height={0.003} viewBox="0 0 0.073 0.003" fill="none" style={{
          position: "absolute",
          left: 0,
          top: 6.5,
          width: 0.073,
          height: 0.003,
          color: "rgb(220,48,39)",
        }}>
          <path d={"M 0.073 0.003 C 0.048 0.002 0.024 0.001 0 0 C 0.024 0.001 0.049 0.002 0.073 0.003 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={6.843} height={2.144} viewBox="0 0 6.843 2.144" fill="none" style={{
          position: "absolute",
          left: 0.508,
          top: 4.367,
          width: 6.843,
          height: 2.144,
          color: "rgb(220,48,39)",
        }}>
          <path d={"M 0 2.144 C 2.544 2.144 4.901 1.35 6.843 0 L 2.5 0 C 1.729 1.328 1.22 2.144 0 2.144 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
      </div>
      <svg width={0.435} height={0.009} viewBox="0 0 0.435 0.009" fill="none" style={{
        position: "absolute",
        left: 11.565,
        top: 23.991,
        width: 0.435,
        height: 0.009,
        color: "rgb(196,33,38)",
      }}>
        <path d={"M 0.435 0.009 C 0.289 0.009 0.144 0.005 0 0 C 0.146 0.005 0.291 0.009 0.435 0.009 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={13.221} height={2.183} viewBox="0 0 13.221 2.183" fill="none" style={{
        position: "absolute",
        left: 2.723,
        top: 2.205,
        width: 13.221,
        height: 2.183,
        color: "rgb(243,244,245)",
      }}>
        <path d={"M 12.3 0 L 2.348 0 C 1.472 0.621 0.681 1.354 0 2.183 L 13.221 2.183 C 12.962 1.366 12.656 0.626 12.3 0 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={9.952} height={2.184} viewBox="0 0 9.952 2.184" fill="none" style={{
        position: "absolute",
        left: 5.071,
        top: 0.022,
        width: 9.952,
        height: 2.184,
        color: "rgb(231,54,37)",
      }}>
        <path d={"M 0 2.184 L 9.952 2.184 C 9.247 0.943 8.349 0.137 7.261 0 L 6.227 0 C 3.914 0.134 1.779 0.923 0 2.184 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={16.357} height={2.183} viewBox="0 0 16.357 2.183" fill="none" style={{
        position: "absolute",
        left: 0.448,
        top: 6.572,
        width: 16.357,
        height: 2.183,
        color: "rgb(243,244,245)",
      }}>
        <path d={"M 0 2.183 L 16.357 2.183 C 16.279 1.433 16.174 0.701 16.04 0 L 0.851 0 C 0.499 0.692 0.213 1.422 0 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={15.189} height={2.183} viewBox="0 0 15.189 2.183" fill="none" style={{
        position: "absolute",
        left: 1.299,
        top: 4.388,
        width: 15.189,
        height: 2.183,
        color: "rgb(231,54,37)",
      }}>
        <path d={"M 1.424 0 C 0.874 0.671 0.397 1.403 0 2.183 L 15.189 2.183 C 15.041 1.411 14.859 0.679 14.645 0 L 1.424 0 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={16.970} height={2.183} viewBox="0 0 16.970 2.183" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 10.939,
        width: 16.97,
        height: 2.183,
        color: "rgb(243,244,245)",
      }}>
        <path d={"M 0 1.061 C 0 1.439 0.02 1.814 0.054 2.183 L 16.951 2.183 C 16.976 1.457 16.977 0.726 16.953 0 L 0.049 0 C 0.019 0.35 0 0.703 0 1.061 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={16.903} height={2.183} viewBox="0 0 16.903 2.183" fill="none" style={{
        position: "absolute",
        left: 0.05,
        top: 8.755,
        width: 16.903,
        height: 2.183,
        color: "rgb(231,54,37)",
      }}>
        <path d={"M 0 2.183 L 16.903 2.183 C 16.879 1.446 16.83 0.715 16.755 0 L 0.398 0 C 0.201 0.704 0.066 1.433 0 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={16.334} height={2.183} viewBox="0 0 16.334 2.183" fill="none" style={{
        position: "absolute",
        left: 0.465,
        top: 15.305,
        width: 16.334,
        height: 2.183,
        color: "rgb(243,244,245)",
      }}>
        <path d={"M 16.334 0 L 0 0 C 0.218 0.762 0.509 1.492 0.865 2.183 L 16.011 2.183 C 16.146 1.483 16.254 0.751 16.334 0 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={16.897} height={2.183} viewBox="0 0 16.897 2.183" fill="none" style={{
        position: "absolute",
        left: 0.054,
        top: 13.122,
        width: 16.897,
        height: 2.183,
        color: "rgb(231,54,37)",
      }}>
        <path d={"M 0.411 2.183 L 16.745 2.183 C 16.821 1.468 16.872 0.737 16.897 0 L 0 0 C 0.07 0.75 0.21 1.479 0.411 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <svg width={13.151} height={2.183} viewBox="0 0 13.151 2.183" fill="none" style={{
        position: "absolute",
        left: 2.774,
        top: 19.672,
        width: 13.151,
        height: 2.183,
        color: "rgb(243,244,245)",
      }}>
        <path d={"M 2.383 2.183 L 12.213 2.183 C 12.575 1.559 12.888 0.821 13.151 0 L 0 0 C 0.691 0.83 1.493 1.565 2.383 2.183 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <div style={{
        position: "absolute",
        left: 1.33,
        top: 17.489,
        width: 15.145,
        height: 6.511,
        overflow: "hidden",
      }}>
        <svg width={15.145} height={2.183} viewBox="0 0 15.145 2.183" fill="none" style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: 15.145,
          height: 2.183,
          color: "rgb(231,54,37)",
        }}>
          <path d={"M 0 0 C 0.403 0.781 0.887 1.514 1.444 2.183 L 14.595 2.183 C 14.812 1.505 14.996 0.773 15.145 0 L 0 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={9.829} height={2.144} viewBox="0 0 9.829 2.144" fill="none" style={{
          position: "absolute",
          left: 3.827,
          top: 4.367,
          width: 9.829,
          height: 2.144,
          color: "rgb(231,54,37)",
        }}>
          <path d={"M 6.335 2.133 C 6.359 2.134 6.383 2.135 6.407 2.136 C 6.552 2.141 6.697 2.144 6.842 2.144 C 8.063 2.144 9.058 1.328 9.829 0 L 0 0 C 1.811 1.26 3.985 2.035 6.335 2.133 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
      </div>
      <svg width={11.701} height={10.913} viewBox="0 0 11.701 10.913" fill="none" style={{
        position: "absolute",
        left: 0.051,
        top: 0.006,
        width: 11.701,
        height: 10.913,
        color: "rgb(40,57,145)",
      }}>
        <path d={"M 11.701 0 C 5.551 0.125 0.539 4.873 0 10.913 L 11.701 10.913 L 11.701 0 L 11.701 0 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <div style={{
        position: "absolute",
        left: 0.404,
        top: 0.832,
        width: 10.729,
        height: 9.431,
        overflow: "hidden",
      }}>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 1.222,
          top: 5.967,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.475} viewBox="0 0 1.550 1.475" fill="none" style={{
          position: "absolute",
          left: 1.222,
          top: 7.956,
          width: 1.55,
          height: 1.475,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.475 L 0.775 1.126 L 0.296 1.475 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 3.211,
          top: 2.983,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 3.211,
          top: 4.973,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 3.211,
          top: 6.962,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={0.783} height={0.952} viewBox="0 0 0.783 0.952" fill="none" style={{
          position: "absolute",
          left: 0,
          top: 7.484,
          width: 0.783,
          height: 0.952,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.487 0.952 L 0.304 0.389 L 0.783 0.041 L 0.191 0.041 L 0.178 0 C 0.113 0.201 0.054 0.405 0 0.61 L 0.008 0.604 L 0.487 0.952 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.295} height={1.474} viewBox="0 0 1.295 1.474" fill="none" style={{
          position: "absolute",
          left: 1.477,
          top: 3.978,
          width: 1.295,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.042 1.474 L 0.52 1.126 L 0.999 1.474 L 0.816 0.911 L 1.295 0.563 L 0.703 0.563 L 0.52 0 L 0.337 0.563 L 0.119 0.563 C 0.079 0.624 0.039 0.686 0 0.748 L 0.224 0.911 L 0.042 1.474 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.254} height={0.911} viewBox="0 0 1.254 0.911" fill="none" style={{
          position: "absolute",
          left: 3.507,
          top: 1.558,
          width: 1.254,
          height: 0.911,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.479 0.563 L 0.958 0.911 L 0.775 0.348 L 1.254 0 L 0.912 0 C 0.622 0.217 0.341 0.447 0.072 0.689 L 0 0.911 L 0.479 0.563 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.254} height={0.987} viewBox="0 0 1.254 0.987" fill="none" style={{
          position: "absolute",
          left: 5.496,
          top: 0.487,
          width: 1.254,
          height: 0.987,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0 0.987 L 0.479 0.639 L 0.958 0.987 L 0.775 0.424 L 1.254 0.076 L 0.662 0.076 L 0.637 0 C 0.436 0.103 0.238 0.209 0.044 0.323 L 0.183 0.424 L 0 0.987 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 5.2,
          top: 1.989,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 5.2,
          top: 3.978,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 5.2,
          top: 5.967,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.475} viewBox="0 0 1.550 1.475" fill="none" style={{
          position: "absolute",
          left: 5.2,
          top: 7.956,
          width: 1.55,
          height: 1.475,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.475 L 0.775 1.126 L 0.296 1.475 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 7.189,
          top: 0.994,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 7.189,
          top: 2.983,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 7.189,
          top: 4.973,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 7.189,
          top: 6.962,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 9.178,
          top: 0,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 9.178,
          top: 1.989,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 9.178,
          top: 3.978,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.474} viewBox="0 0 1.550 1.474" fill="none" style={{
          position: "absolute",
          left: 9.178,
          top: 5.967,
          width: 1.55,
          height: 1.474,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.474 L 0.775 1.126 L 0.296 1.474 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
        <svg width={1.550} height={1.475} viewBox="0 0 1.550 1.475" fill="none" style={{
          position: "absolute",
          left: 9.178,
          top: 7.956,
          width: 1.55,
          height: 1.475,
          color: "rgb(239,239,239)",
        }}>
          <path d={"M 0.775 0 L 0.958 0.563 L 1.55 0.563 L 1.071 0.911 L 1.254 1.475 L 0.775 1.126 L 0.296 1.475 L 0.479 0.911 L 0 0.563 L 0.592 0.563 L 0.775 0 Z"} fill="currentColor" fillRule="evenodd" />
        </svg>
      </div>
    </div>
  );
}
export default USFlag;
